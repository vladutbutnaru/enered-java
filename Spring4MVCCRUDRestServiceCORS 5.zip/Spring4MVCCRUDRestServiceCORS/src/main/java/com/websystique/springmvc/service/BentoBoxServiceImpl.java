package com.websystique.springmvc.service;

import com.websystique.springmvc.model.BentoBox;
import com.websystique.springmvc.model.Restaurant;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.atomic.AtomicLong;

/**
 * Created by macbook on 11/01/2017.
 */
@Service("bentoBoxService")
@Transactional
public class BentoBoxServiceImpl implements BentoBoxService {
    private static final AtomicLong counter = new AtomicLong();

    private static List<BentoBox> bentoBoxes = new ArrayList<BentoBox>();

    public BentoBox findById(int id) {
        for(BentoBox bentoBox : bentoBoxes){
            if(bentoBox.getId() == id){
                return bentoBox;
            }
        }
        return null;
    }

    public void saveBentoBox(BentoBox bentoBox) {
        bentoBox.setId((int) counter.incrementAndGet());
        bentoBoxes.add(bentoBox);

    }

    public void updateBentoBox(BentoBox bentoBox) {
            BentoBox old = findById(bentoBox.getId());
            old.setCustomerId(bentoBox.getCustomerId());
         old.setDescription(bentoBox.getDescription());
        old.setImage(bentoBox.getImage());
        old.setPaymentCode(bentoBox.getPaymentCode());
        old.setPrice(bentoBox.getPrice());
        old.setQualityCheck(bentoBox.getQualityCheck());

    }

    public void deleteBentoBoxById(int id) {
BentoBox old = findById(id);
        bentoBoxes.remove(old);

    }

    public List<BentoBox> findAllBentoBoxes() {
        return bentoBoxes;
    }

    public boolean isBentoBoxExist(BentoBox bentoBox) {
        return false;
    }
}
