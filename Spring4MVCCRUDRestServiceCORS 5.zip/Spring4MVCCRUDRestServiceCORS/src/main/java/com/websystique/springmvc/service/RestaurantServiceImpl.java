package com.websystique.springmvc.service;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.concurrent.atomic.AtomicLong;

import com.websystique.springmvc.model.Restaurant;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service("restaurantService")
@Transactional
public class RestaurantServiceImpl implements RestaurantService{
	
	private static final AtomicLong counter = new AtomicLong();
	
	private static List<Restaurant> restaurants;
	
	static{
		restaurants= populateDummyRestaurants();
	}

	public List<Restaurant> findAllRestaurants() {
		return restaurants;
	}
	
	public Restaurant findById(long id) {
		for(Restaurant restaurant : restaurants){
			if(restaurant.getId() == id){
				return restaurant;
			}
		}
		return null;
	}
	
	public Restaurant findByName(String name) {
		for(Restaurant restaurant : restaurants){
			if(restaurant.getName().equalsIgnoreCase(name)){
				return restaurant;
			}
		}
		return null;
	}
	
	public void saveRestaurant(Restaurant restaurant) {
		restaurant.setId(counter.incrementAndGet());
		restaurants.add(restaurant);
	}

	public void updateRestaurant(Restaurant restaurant) {
		int index = restaurants.indexOf(restaurant);
		restaurants.set(index, restaurant);
	}

	public void deleteRestaurantById(long id) {
		
		for (Iterator<Restaurant> iterator = restaurants.iterator(); iterator.hasNext(); ) {
			Restaurant restaurant = iterator.next();
		    if (restaurant.getId() == id) {
		        iterator.remove();
		    }
		}
	}

	public boolean isRestaurantExist(Restaurant restaurant) {
		return findByName(restaurant.getName())!=null;
	}
	
	public void deleteAllRestaurants(){
		restaurants.clear();
	}

	private static List<Restaurant> populateDummyRestaurants(){
		List<Restaurant> restaurants = new ArrayList<Restaurant>();
		restaurants.add(new Restaurant(counter.incrementAndGet(),"Sam", 24.4, 25.1, 1));
		restaurants.add(new Restaurant(counter.incrementAndGet(),"Tom",25.4, 25.8, 2));
		restaurants.add(new Restaurant(counter.incrementAndGet(),"Jerome",26.4, 25.5, 2));
		restaurants.add(new Restaurant(counter.incrementAndGet(),"Silvia",27.4, 25.3, 1));
		return restaurants;
	}

}
