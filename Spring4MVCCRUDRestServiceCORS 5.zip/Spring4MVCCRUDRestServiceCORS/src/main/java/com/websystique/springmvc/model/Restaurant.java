package com.websystique.springmvc.model;

public class Restaurant {

	private long id;
	
	private String name;
	
	private double x;
	
	private double y;

	private int type;

	public Restaurant(){
		id=0;
	}
	
	public Restaurant(long id, String name, double x, double y, int type){
		this.id = id;
		this.name = name;
		this.x = x;
		this.y = y;
		this.type=type;
	}
	
	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public double getX() {
		return x;
	}

	public void setX(double x) {
		this.x = x;
	}

	public double getY() {
		return y;
	}

	public void setY(double y) {
		this.y = y;
	}

	public int getType() {
		return type;
	}

	public void setType(int type) {
		this.type = type;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + (int) (id ^ (id >>> 32));
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Restaurant other = (Restaurant) obj;
		if (id != other.id)
			return false;
		return true;
	}

	@Override
	public String toString() {
		return "Restaurant [id=" + id + ", name=" + name + ", x=" + x
				+ ", y=" + y + ", type=" + type + "]";
	}


}
