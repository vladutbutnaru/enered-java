package com.websystique.springmvc.service;

import java.util.List;

import com.websystique.springmvc.model.Restaurant;




public interface RestaurantService {
	
	Restaurant findById(long id);

	Restaurant findByName(String name);
	
	void saveRestaurant(Restaurant restaurant);
	
	void updateRestaurant(Restaurant restaurant);
	
	void deleteRestaurantById(long id);

	List<Restaurant> findAllRestaurants();
	
	void deleteAllRestaurants();
	
	public boolean isRestaurantExist(Restaurant restaurant);
	
}
