package com.websystique.springmvc.controller;
 
import java.util.List;

import com.websystique.springmvc.model.BentoBox;
import com.websystique.springmvc.model.Restaurant;
import com.websystique.springmvc.service.BentoBoxService;
import com.websystique.springmvc.service.RestaurantService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.util.UriComponentsBuilder;

 
@RestController
public class HelloWorldRestController {
 
    @Autowired
    RestaurantService restaurantService;  //Service which will do all data retrieval/manipulation work

    @Autowired
    BentoBoxService bentoBoxService;


    //-------------------Retrieve All Bento Boxes--------------------------------------------------------

    @RequestMapping(value = "/bentobox/all", method = RequestMethod.GET)
    public ResponseEntity<List<BentoBox>> listAllBoxes() {
        List<BentoBox> boxes = bentoBoxService.findAllBentoBoxes();
        if(boxes.isEmpty()){
            return new ResponseEntity<List<BentoBox>>(HttpStatus.NO_CONTENT);
        }
        return new ResponseEntity<List<BentoBox>>(boxes, HttpStatus.OK);
    }


    //-------------------Create a Bento Box--------------------------------------------------------

    @RequestMapping(value = "/bentobox/add", method = RequestMethod.POST)
    public ResponseEntity<Void> createBox(@RequestBody BentoBox box,    UriComponentsBuilder ucBuilder) {

        bentoBoxService.saveBentoBox(box);

        HttpHeaders headers = new HttpHeaders();
        headers.setLocation(ucBuilder.path("/bentobox/{id}").buildAndExpand(box.getId()).toUri());
        return new ResponseEntity<Void>(headers, HttpStatus.CREATED);
    }



    //-------------------Retrieve Single Box--------------------------------------------------------

    @RequestMapping(value = "/bentobox/{id}", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<BentoBox> getRestaurant(@PathVariable("id") int id) {

        BentoBox box = bentoBoxService.findById(id);
        if (box == null) {

            return new ResponseEntity<BentoBox>(HttpStatus.NOT_FOUND);
        }
        return new ResponseEntity<BentoBox>(box, HttpStatus.OK);
    }











    //-------------------Retrieve All Restaurants--------------------------------------------------------
     
    @RequestMapping(value = "/restaurant/", method = RequestMethod.GET)
    public ResponseEntity<List<Restaurant>> listAllRestaurants() {
        List<Restaurant> restaurants = restaurantService.findAllRestaurants();
        if(restaurants.isEmpty()){
            return new ResponseEntity<List<Restaurant>>(HttpStatus.NO_CONTENT);
        }
        return new ResponseEntity<List<Restaurant>>(restaurants, HttpStatus.OK);
    }
 
 
    //-------------------Retrieve Single Restaurant--------------------------------------------------------
     
    @RequestMapping(value = "/restaurant/{id}", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<Restaurant> getRestaurant(@PathVariable("id") long id) {
        System.out.println("Fetching Restaurant with id " + id);
        Restaurant restaurant = restaurantService.findById(id);
        if (restaurant == null) {
            System.out.println("Restaurant with id " + id + " not found");
            return new ResponseEntity<Restaurant>(HttpStatus.NOT_FOUND);
        }
        return new ResponseEntity<Restaurant>(restaurant, HttpStatus.OK);
    }
 
     
     
    //-------------------Create a Restaurant--------------------------------------------------------
     
    @RequestMapping(value = "/restaurant/", method = RequestMethod.POST)
    public ResponseEntity<Void> createRestaurant(@RequestBody Restaurant restaurant,    UriComponentsBuilder ucBuilder) {
        System.out.println("Creating Restaurant " + restaurant.getName());
 
        if (restaurantService.isRestaurantExist(restaurant)) {
            System.out.println("A restaurant with name " + restaurant.getName() + " already exist");
            return new ResponseEntity<Void>(HttpStatus.CONFLICT);
        }

        restaurantService.saveRestaurant(restaurant);
 
        HttpHeaders headers = new HttpHeaders();
        headers.setLocation(ucBuilder.path("/restaurant/{id}").buildAndExpand(restaurant.getId()).toUri());
        return new ResponseEntity<Void>(headers, HttpStatus.CREATED);
    }
 
     
    //------------------- Update a Restaurant --------------------------------------------------------
     
    @RequestMapping(value = "/restaurant/{id}", method = RequestMethod.PUT)
    public ResponseEntity<Restaurant> updateRestaurant(@PathVariable("id") long id, @RequestBody Restaurant restaurant) {
        System.out.println("Updating Restaurant " + id);

        Restaurant currentRestaurant = restaurantService.findById(id);
         
        if (currentRestaurant==null) {
            System.out.println("Restaurant with id " + id + " not found");
            return new ResponseEntity<Restaurant>(HttpStatus.NOT_FOUND);
        }

        currentRestaurant.setName(restaurant.getName());
        currentRestaurant.setX(restaurant.getX());
        currentRestaurant.setY(restaurant.getY());

        restaurantService.updateRestaurant(currentRestaurant);
        return new ResponseEntity<Restaurant>(currentRestaurant, HttpStatus.OK);
    }
 
    //------------------- Delete a Restaurant --------------------------------------------------------
     
    @RequestMapping(value = "/restaurant/{id}", method = RequestMethod.DELETE)
    public ResponseEntity<Restaurant> deleteRestaurant(@PathVariable("id") long id) {
        System.out.println("Fetching & Deleting Restaurant with id " + id);

        Restaurant restaurant = restaurantService.findById(id);
        if (restaurant == null) {
            System.out.println("Unable to delete. Restaurant with id " + id + " not found");
            return new ResponseEntity<Restaurant>(HttpStatus.NOT_FOUND);
        }

        restaurantService.deleteRestaurantById(id);
        return new ResponseEntity<Restaurant>(HttpStatus.NO_CONTENT);
    }
 
     
    //------------------- Delete All Restaurants --------------------------------------------------------
     
    @RequestMapping(value = "/restaurant/", method = RequestMethod.DELETE)
    public ResponseEntity<Restaurant> deleteALlRestaurants() {
        System.out.println("Deleting All Restaurants");

        restaurantService.deleteAllRestaurants();
        return new ResponseEntity<Restaurant>(HttpStatus.NO_CONTENT);
    }
 
}