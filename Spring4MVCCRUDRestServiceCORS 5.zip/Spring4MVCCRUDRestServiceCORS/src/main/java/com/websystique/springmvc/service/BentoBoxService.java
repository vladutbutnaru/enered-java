package com.websystique.springmvc.service;

import com.websystique.springmvc.model.BentoBox;
import com.websystique.springmvc.model.Restaurant;

import java.util.List;

/**
 * Created by macbook on 11/01/2017.
 */
public interface BentoBoxService {

    BentoBox findById(int id);

    void saveBentoBox(BentoBox bentoBox);

    void updateBentoBox(BentoBox bentoBox);

    void deleteBentoBoxById(int id);

    List<BentoBox> findAllBentoBoxes();

    public boolean isBentoBoxExist(BentoBox bentoBox);


}
