package com.websystique.springmvc;
 
import java.net.URI;
import java.util.LinkedHashMap;
import java.util.List;

import com.websystique.springmvc.model.Restaurant;
import org.springframework.web.client.RestTemplate;

 
public class SpringRestTestClient {
 
    public static final String REST_SERVICE_URI = "http://localhost:8080";
     
    /* GET */
    @SuppressWarnings("unchecked")
    private static void listAllRestaurants(){
        System.out.println("Testing listAllRestaurants API-----------");
         
        RestTemplate restTemplate = new RestTemplate();
        List<LinkedHashMap<String, Object>> restaurantsMap = restTemplate.getForObject(REST_SERVICE_URI+"/restaurant/", List.class);
         
        if(restaurantsMap!=null){
            for(LinkedHashMap<String, Object> map : restaurantsMap){
                System.out.println("Restaurant : id="+map.get("id")+", Name="+map.get("name")+", x="+map.get("x")+", y="+map.get("y"));;
            }
        }else{
            System.out.println("No Restaurant exist----------");
        }
    }
     
    /* GET */
    private static void getRestaurant(){
        System.out.println("Testing getRestaurant API----------");
        RestTemplate restTemplate = new RestTemplate();
        Restaurant restaurant = restTemplate.getForObject(REST_SERVICE_URI+"/restaurant/1", Restaurant.class);
        System.out.println(restaurant);
    }
     
    /* POST */
    private static void createRestaurant() {
        System.out.println("Testing create Restaurant API----------");
        RestTemplate restTemplate = new RestTemplate();
        Restaurant restaurant = new Restaurant(0,"Test Restaurant",51.4,52.1,3);
        URI uri = restTemplate.postForLocation(REST_SERVICE_URI+"/restaurant/", restaurant, Restaurant.class);
        System.out.println("Location : "+uri.toASCIIString());
    }
 
    /* PUT */
    private static void updateRestaurant() {
        System.out.println("Testing update Restaurant API----------");
        RestTemplate restTemplate = new RestTemplate();
        Restaurant restaurant  = new Restaurant(1,"Test restaurant 2",33.1, 33.2, 1);
        restTemplate.put(REST_SERVICE_URI+"/restaurant/1", restaurant);
        System.out.println(restaurant);
    }
 
    /* DELETE */
    private static void deleteRestaurant() {
        System.out.println("Testing delete Restaurant API----------");
        RestTemplate restTemplate = new RestTemplate();
        restTemplate.delete(REST_SERVICE_URI+"/restaurant/3");
    }
 
 
    /* DELETE */
    private static void deleteAllRestaurants() {
        System.out.println("Testing all delete Restaurants API----------");
        RestTemplate restTemplate = new RestTemplate();
        restTemplate.delete(REST_SERVICE_URI+"/restaurant/");
    }
 
    public static void main(String args[]){
        listAllRestaurants();
        getRestaurant();
        createRestaurant();
        listAllRestaurants();
        updateRestaurant();
        listAllRestaurants();
        deleteRestaurant();
        listAllRestaurants();
        deleteAllRestaurants();
        listAllRestaurants();
    }
}