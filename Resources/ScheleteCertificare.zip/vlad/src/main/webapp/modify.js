function modify(articleID) {
	var id = document.getElementById("id" + articleID).innerHTML;
	var title = document.getElementById("title" + articleID).innerHTML;
	var content = document.getElementById("content" + articleID).innerHTML;

	document.getElementById("editTitle").value = title;
	document.getElementById("editContent").value = content;

	document.getElementById("editId").value = id;
}
