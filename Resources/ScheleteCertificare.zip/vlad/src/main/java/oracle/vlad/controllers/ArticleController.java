package oracle.vlad.controllers;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;

import oracle.vlad.beans.Article;
import oracle.vlad.utils.DBConnection;

public class ArticleController {
	Connection c = DBConnection.getConnection();
	ResultSet rs;

	public ArrayList<Article> getArticles() throws Exception {
		PreparedStatement ps = c.prepareStatement("" + "SELECT * FROM Articles");
		ArrayList<Article> articles = new ArrayList<Article>();
		rs = ps.executeQuery();
		while(rs.next()){
			Article a = new Article();
			a.setId(rs.getInt(1));
			a.setTitle(rs.getString(2));
			a.setContent(rs.getString(3));
			a.setPublisherID(rs.getInt(4));
			articles.add(a);
		}
	return articles;
	}
	public void addArticle(Article a) throws Exception{
		PreparedStatement ps = c.prepareStatement(""
				+ "INSERT INTO Articles(Title,Content,PublisherID) "
				+ "VALUES(?,?,?) "
				+ "");
		ps.setString(1, a.getTitle());
		ps.setString(2, a.getContent());
		ps.setInt(3, a.getPublisherID());
		ps.executeUpdate();
	}
	public void deleteArticle(int id)throws Exception{
		PreparedStatement ps = c.prepareStatement(""
				+ "DELETE FROM Articles WHERE ID = ?");
		ps.setInt(1, id);
		ps.executeUpdate();
		
	}

}
