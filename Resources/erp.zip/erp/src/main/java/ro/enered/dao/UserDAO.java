package ro.enered.dao;

import ro.enered.beans.User;

public interface UserDAO {
	public int checkLogin(User u);
	
}
