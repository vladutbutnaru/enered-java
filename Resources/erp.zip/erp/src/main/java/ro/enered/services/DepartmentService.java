package ro.enered.services;

import java.util.ArrayList;
import java.util.List;

import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

import ro.enered.beans.Department;
import ro.enered.beans.Employee;

public class DepartmentService {
	private static SessionFactory factory;

	public DepartmentService() {

		try {
			factory = new Configuration().configure().buildSessionFactory();
		} catch (Throwable ex) {
			System.err.println("Failed to create sessionFactory object." + ex);
			throw new ExceptionInInitializerError(ex);
		}

	}
	
	public int getNumberOfDepartments(){
		int nr=0;
		List<Department> departments = new ArrayList<Department>();
		Session session = factory.getCurrentSession();
		Transaction transaction = null;
		try {
			transaction = session.beginTransaction();
			
			departments = session.createQuery("FROM Department").list();
			for (Department department : departments) {
				nr++;
			}
			transaction.commit();
		} catch (HibernateException e) {
			System.out.println("AM CRAPAT");
			transaction.rollback();
		} finally {
			session.close();
		}

		return nr;
		
		
		
		
	}
}
