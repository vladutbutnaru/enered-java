package ro.enered.services;

import java.util.ArrayList;
import java.util.List;

import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

import ro.enered.beans.Employee;
import ro.enered.beans.User;
import ro.enered.dao.EmployeeDAO;

public class EmplyeeService implements EmployeeDAO {
	private static SessionFactory factory;

	public EmplyeeService() {

		try {
			factory = new Configuration().configure().buildSessionFactory();
		} catch (Throwable ex) {
			System.err.println("Failed to create sessionFactory object." + ex);
			throw new ExceptionInInitializerError(ex);
		}

	}
	public int getNumberOfEmployees() {
		int nr=0;
		List<Employee> users = new ArrayList<Employee>();
		Session session = factory.getCurrentSession();
		Transaction transaction = null;
		try {
			transaction = session.beginTransaction();
			
			users = session.createQuery("FROM Employee").list();
			for (Employee us : users) {
				nr++;
			}
			transaction.commit();
		} catch (HibernateException e) {
			System.out.println("AM CRAPAT");
			transaction.rollback();
		} finally {
			session.close();
		}

		return nr;
	}
	
	
	public double getMedianSalary() {
		double nr=0;
	
		List<Employee> users = new ArrayList<Employee>();
		Session session = factory.getCurrentSession();
		Transaction transaction = null;
		try {
			transaction = session.beginTransaction();
			
			users = session.createQuery("FROM Employee").list();
			for (Employee us : users) {
				nr=nr+us.getSalary();
			}
			transaction.commit();
		} catch (HibernateException e) {
			System.out.println("AM CRAPAT");
			transaction.rollback();
		} finally {
			session.close();
		}

		return nr/getNumberOfEmployees();
	}
	
	public double getTotalSalary(){
		double nr=0;
		
		List<Employee> users = new ArrayList<Employee>();
		Session session = factory.getCurrentSession();
		Transaction transaction = null;
		try {
			transaction = session.beginTransaction();
			
			users = session.createQuery("FROM Employee").list();
			for (Employee us : users) {
				nr=nr+us.getSalary();
			}
			transaction.commit();
		} catch (HibernateException e) {
			System.out.println("AM CRAPAT");
			transaction.rollback();
		} finally {
			session.close();
		}

		return nr;
		
	
	}
}
