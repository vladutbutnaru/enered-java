package ro.enered.dao;

public interface EmployeeDAO {
public int getNumberOfEmployees();
}
