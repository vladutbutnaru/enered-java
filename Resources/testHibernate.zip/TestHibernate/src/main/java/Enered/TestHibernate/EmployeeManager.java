package Enered.TestHibernate;

import java.util.ArrayList;
import java.util.List;

import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

import test.veans.Employee;

public class EmployeeManager {
	private static SessionFactory factory;
	
	public EmployeeManager(){
		 try{
	         factory = new Configuration().configure().buildSessionFactory();
	      }catch (Throwable ex) { 
	         System.err.println("Failed to create sessionFactory object." + ex);
	         throw new ExceptionInInitializerError(ex); 
	      }
	}
	
	public Integer addEmployee(Employee emp){
		Session session = factory.getCurrentSession();
		Transaction transaction = null;
		Integer employeeID = null;
		try{
			transaction = session.beginTransaction();
			employeeID = (Integer) session.save(emp);			
			transaction.commit();
		}
		catch(HibernateException e){
			System.out.println("AM CRAPAT");
			transaction.rollback();			
		}		
		finally{
			session.close();
		}
		return employeeID;
		
	}
	public List<Employee> listEmployees(){
		List<Employee> employees = new ArrayList<Employee>();
		Session session = factory.getCurrentSession();
		Transaction transaction = null;
		try{
			transaction = session.beginTransaction();
			employees = session.createQuery("FROM Employee").list();
			for(Employee e : employees){
				System.out.print("ID: " + e.getId());
				System.out.print("First Name: " + e.getFirstName());
				System.out.print(" Last Name: " + e.getLastName());
				System.out.println("Salary: " + e.getSalary());
			}
			transaction.commit();
		}
		catch(HibernateException e){
			System.out.println("AM CRAPAT");
			transaction.rollback();			
		}		
		finally{
			session.close();
		}
		
		return employees;
		
	}
	
	public void updateEmployee(Employee e, int salary){
		Session session = factory.getCurrentSession();
		Transaction transaction = null;
	
		try{
			transaction = session.beginTransaction();
			e = (Employee) session.get(Employee.class, e.getId());	
			e.setSalary(salary);
			session.update(e);
			transaction.commit();
		}
		catch(HibernateException ex){
			System.out.println("AM CRAPAT");
			transaction.rollback();			
		}		
		finally{
			session.close();
		}
		
		
	}
	
	
	public void deleteEmployee(Employee e){
		Session session = factory.getCurrentSession();
		Transaction transaction = null;
	
		try{
			transaction = session.beginTransaction();
			e = (Employee) session.get(Employee.class, e.getId());	
			
			session.delete(e);
			transaction.commit();
		}
		catch(HibernateException ex){
			System.out.println("AM CRAPAT");
			transaction.rollback();			
		}		
		finally{
			session.close();
		}
		
		
	}
	
}
