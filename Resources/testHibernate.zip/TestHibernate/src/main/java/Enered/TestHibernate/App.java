package Enered.TestHibernate;

import test.veans.Employee;

/**
 * Hello world!
 *
 */
public class App {
	public static void main(String[] args) {
		EmployeeManager em = new EmployeeManager();
	
		em.listEmployees();
		Employee e = new Employee();
		e.setId(3);
		em.updateEmployee(e,1);
		System.out.println(" ");
		em.listEmployees();
		System.out.println(" ");
		e.setId(7);
		em.deleteEmployee(e);
		em.listEmployees();
	}
}
