package servlets;

public class Configuration {
	public static final String DATABASE_URL="46.101.150.186";
	public static final int DATABASE_PORT=3306;
	public static final String DATABASE_NAME="mail";
	public static final String DATABASE_USER="root";
	public static final String DATABASE_PASSWORD="BaniiMeiDev1!";
	public static final int STANDARD_SUBSCRIPTION = 1;
	public static final int ELITE_SUBSCRIPTION = 2;
	public static final int BETA_TESTER = 3;
	public static final int FREE_TRIAL = 4;
}
