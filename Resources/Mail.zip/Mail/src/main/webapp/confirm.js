function confirm() {
	var user = document.getElementById("user").value;
	var cod = document.getElementById("cod").value;

	$.post("ConfirmAccount", {
		mail : user,
		cod : cod

	}, function(data) {
		if (data == "OK")
			alert("Activat");
		else
			alert("Cod gresit");
		location.href = "Login.jsp";

	}

	);

}