function login() {
	var user = document.getElementById("user").value;
	var pass = document.getElementById("pass").value;
	$.post("LoginServlet", {
		user : user,
		pass : pass

	}, function(data) {
		if (data == "OK") {
			alert("Welcome");
		} else {
			alert("Go away");
		}
	});
}