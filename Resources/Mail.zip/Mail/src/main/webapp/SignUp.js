function signup(){
var user=document.getElementById("user").value;	
var pass=document.getElementById("pass").value;	

$.post("SignUpservlet", {
	mail:user,
	pass:pass
	
},
function(data){
	
	alert("Activati mail");
	
	location.href="Confirmation.jsp";
	
}

);
	
	
	
	
	
}