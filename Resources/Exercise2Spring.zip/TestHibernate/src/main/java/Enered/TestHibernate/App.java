package Enered.TestHibernate;

import test.beans.Employee;

public class App {
	public static void main(String[] args) {

		// old manager
		// EmployeeManager em = new EmployeeManager();
		// Employee e = new Employee();
		// e.setFirstName("Costel");
		// e.setLastName("Franaru");
		// e.setSalary(1000);
		// em.listEmployees();
		// System.out.println(em.addEmployee(e));
		// em.listEmployees();
	}
}
