package Enered.TestHibernate;

import java.util.ArrayList;
import java.util.List;

import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

public class EmployeeManager {
	// private static SessionFactory factory;
	//
	// public EmployeeManager() {
	// factory = new Configuration().configure().buildSessionFactory();
	//
	// }
	//
	// public Integer addEmployee(Employee emp) {
	// Session session = factory.getCurrentSession();
	// Transaction transaction = null;
	// Integer employeeID = null;
	// try {
	// transaction = session.beginTransaction();
	// employeeID = (Integer) session.save(emp);
	// transaction.commit();
	// } catch (HibernateException e) {
	// System.out.println("Fail");
	// transaction.rollback();
	// } finally {
	// session.close();
	// }
	// return employeeID;
	// }
	//
	// public List<Employee> listEmployees() {
	// List<Employee> employees = new ArrayList<Employee>();
	// Session session = factory.getCurrentSession();
	// Transaction transaction = null;
	// Integer employeeID = null;
	// try {
	// transaction = session.beginTransaction();
	// employees = session.createQuery("FROM Employee").list();
	// for (Employee e : employees) {
	// System.out.print("First Name: " + e.getFirstName());
	// System.out.print(" Last Name: " + e.getLastName());
	// System.out.println(" Salary: " + e.getSalary());
	// }
	//
	// transaction.commit();
	// } catch (HibernateException e) {
	// System.out.println("Fail");
	// transaction.rollback();
	// } finally {
	// session.close();
	// }
	// return employees;
	// }

}
