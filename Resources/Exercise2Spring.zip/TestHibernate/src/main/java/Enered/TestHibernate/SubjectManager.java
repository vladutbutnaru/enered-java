package Enered.TestHibernate;

import java.util.ArrayList;
import java.util.List;

import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

import test.beans.Student;
import test.beans.Subject;

public class SubjectManager {
	private static SessionFactory factory;

	public SubjectManager() {
		factory = new Configuration().configure().buildSessionFactory();

	}

	public Integer addSubject(Subject sbj) {
		Session session = factory.getCurrentSession();
		Transaction transaction = null;
		Integer subjectID = null;
		try {
			transaction = session.beginTransaction();
			subjectID = (Integer) session.save(sbj);
			transaction.commit();
		} catch (HibernateException e) {
			System.out.println("Fail");
			transaction.rollback();
		} finally {
			session.close();
		}
		return subjectID;
	}

	public List<Subject> listSubjects() {
		List<Subject> subjects = new ArrayList<Subject>();
		Session session = factory.getCurrentSession();
		Transaction transaction = null;
		Integer subjectID = null;
		try {
			transaction = session.beginTransaction();
			subjects = session.createQuery("FROM Subject").list();
			transaction.commit();
		} catch (HibernateException e) {
			System.out.println("Fail");
			transaction.rollback();
		} finally { 
			session.close();
		}
		return subjects;
	}

}
