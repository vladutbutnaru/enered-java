package Enered.TestHibernate;

import java.util.ArrayList;
import java.util.List;

import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

import test.beans.Classes;
import test.beans.Grade;

public class GradeManager {
	private static SessionFactory factory;

	public GradeManager() {
		factory = new Configuration().configure().buildSessionFactory();

	}

	public Integer addGrade(Grade grd) {
		Session session = factory.getCurrentSession();
		Transaction transaction = null;
		Integer gradeID = null;
		try {
			transaction = session.beginTransaction();
			gradeID = (Integer) session.save(grd);
			transaction.commit();
		} catch (HibernateException e) {
			System.out.println("Fail");
			transaction.rollback();
		} finally {
			session.close();
		}
		return gradeID;
	}

	public List<Grade> listGrades() {
		List<Grade> grades = new ArrayList<Grade>();
		Session session = factory.getCurrentSession();
		Transaction transaction = null;
		Integer gradeID = null;
		try {
			transaction = session.beginTransaction();
			grades = session.createQuery("FROM Grade").list();
			transaction.commit();
		} catch (HibernateException e) {
			System.out.println("Fail");
			transaction.rollback();
		} finally {
			session.close();
		}
		return grades;
	}

}
