package Enered.TestHibernate;

import java.util.ArrayList;
import java.util.List;

import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

import test.beans.Classes;

public class ClassesManager {
	private static SessionFactory factory;

	public ClassesManager() {
		factory = new Configuration().configure().buildSessionFactory();

	}

	public Integer addClass(Classes cls) {
		Session session = factory.getCurrentSession();
		Transaction transaction = null;
		Integer classID = null;
		try {
			transaction = session.beginTransaction();
			classID = (Integer) session.save(cls);
			transaction.commit();
		} catch (HibernateException e) {
			System.out.println("Fail");
			transaction.rollback();
		} finally {
			session.close();
		}
		return classID;
	}

	public List<Classes> listClasses() {
		List<Classes> classes = new ArrayList<Classes>();
		Session session = factory.getCurrentSession();
		Transaction transaction = null;
		Integer classID = null;
		try {
			transaction = session.beginTransaction();
			classes = session.createQuery("FROM Classes").list();
			transaction.commit();
		} catch (HibernateException e) {
			System.out.println("Fail");
			transaction.rollback();
		} finally {
			session.close();
		}
		return classes;
	}

}
