package Enered.TestHibernate;

import java.util.ArrayList;
import java.util.List;

import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

import test.beans.Student;

public class StudentManager {
	private static SessionFactory factory;

	public StudentManager() {
		factory = new Configuration().configure().buildSessionFactory();

	}

	public Integer addStudent(Student std) {
		Session session = factory.getCurrentSession();
		Transaction transaction = null;
		Integer studentID = null;
		try {
			transaction = session.beginTransaction();
			studentID = (Integer) session.save(std);
			transaction.commit();
		} catch (HibernateException e) {
			System.out.println("Fail");
			transaction.rollback();
		} finally {
			session.close();
		}
		return studentID;
	}

	public List<Student> listStudents() {
		List<Student> students = new ArrayList<Student>();
		Session session = factory.getCurrentSession();
		Transaction transaction = null;
		Integer studentID = null;
		try {
			transaction = session.beginTransaction();
			students = session.createQuery("FROM Student").list();
			transaction.commit();
		} catch (HibernateException e) {
			System.out.println("Fail");
			transaction.rollback();
		} finally {
			session.close();
		}
		return students;
	}
}
