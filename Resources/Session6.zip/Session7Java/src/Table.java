import java.util.ArrayList;


public class Table {
private boolean available;
private int nrMasa;
ArrayList<User> users;
//constructor START
public Table(int index){
	setNrMasa(index); // == this.index=index
	users = new ArrayList<User>(); //instantiem
	setAvailable(true); //la inceput sunt available
	
}
//constructor END
//setters and getters
public boolean isAvailable() {
	return available;
}
public void setAvailable(boolean available) {
	this.available = available;
}
public int getNrMasa() {
	return nrMasa;
}
public void setNrMasa(int index) {
	this.nrMasa = index;
}
public ArrayList<User> getUsers() {
	return users;
}
public void setUsers(ArrayList<User> users) {
	this.users = users;
}
//getters and setters END
//methods START
public void reserve(User u){
	//check if table is available
	if(isAvailable()){
		//reserve it by adding the user to the list
	users.add(u);
	//and setting the available flag to false
	setAvailable(false);
	System.out.println("The table was reserved successfully");
	}
	else{
		System.out.println("The table is already reserved");
	}
}
public void leaveTable(){
	setAvailable(true);
}
public void showHistory(){
	System.out.println("The table with number: " + getNrMasa() + " had the following customers: ");
	for(int i=0; i<users.size(); i++){
		System.out.println(users.get(i).getName());
		
	}
	System.out.println();
}
}
