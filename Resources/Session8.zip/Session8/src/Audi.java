
public class Audi extends Car {
//constructor
	public Audi(String brand){
	super.setBrand(brand);
	
}
}
