
public class Fish extends Animal {
public Fish(){
	super.setMammal(false);
	
}
public void swim(){
	System.out.println("The fish with color: " + super.getColor() + " swims...");
	
}
}
