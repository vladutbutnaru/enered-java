package ro.enered.inheritance;

public class Masina {
private String nrAuto;
private String color;
public String getNrAuto() {
	return nrAuto;
}
public void setNrAuto(String nrAuto) {
	this.nrAuto = nrAuto;
}
public String getColor() {
	return color;
}
public void setColor(String color) {
	this.color = color;
}

}
