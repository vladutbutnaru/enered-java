package ro.enered.inheritance;

public class Asigurare extends Masina {
private String expires;

public String getExpires() {
	return expires;
}

public void setExpires(String expires) {
	this.expires = expires;
}
//overloading 
public void pay(){
	System.out.println("RCA-ul costa standard 300 RON");
}
public void pay(String casco){
	System.out.println(casco + "-ul costa 700 RON in plus");
}
}
