package ro.enered.interfaces;

public interface Tva {
public double calculatePrice();
}
