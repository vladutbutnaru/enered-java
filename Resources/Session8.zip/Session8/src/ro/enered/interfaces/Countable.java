package ro.enered.interfaces;

public interface Countable {
public int count();
}
