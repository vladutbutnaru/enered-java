
public class Vehicle {
private int numOfWheels;
private String name;
private boolean hasWheels;
public int getNumOfWheels() {
	return numOfWheels;
}
public void setNumOfWheels(int numOfWheels) {
	this.numOfWheels = numOfWheels;
}
public String getName() {
	return name;
}
public void setName(String name) {
	this.name = name;
}
public boolean isHasWheels() {
	return hasWheels;
}
public void setHasWheels(boolean hasWheels) {
	this.hasWheels = hasWheels;
}
}
