
public class Cat extends Animal{
public void maiuna(){
	//daca este mamifer, atunci afisam "The mammal with color..
	if(super.isMammal())
		System.out.println("The mammal with color: " + super.getColor() + " says meow");
	else
		System.out.println("The cat with color: " + super.getColor() + " says meow");

}
public void maiuna(int numOfTimes){
	for(int i=0; i<numOfTimes; i++){
		System.out.println("The cat with color " + super.getColor() + " says meow");
	}
	
}
}
