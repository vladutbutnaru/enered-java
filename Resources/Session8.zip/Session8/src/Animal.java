
public class Animal {
private String color;
private boolean mammal;
public String getColor() {
	return color;
}
public void setColor(String color) {
	this.color = color;
}
public boolean isMammal() {
	return mammal;
}
public void setMammal(boolean mammal) {
	this.mammal = mammal;
}
}
