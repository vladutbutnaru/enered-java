var nume;

function login() {
  nume = "salut";  $.post("http://localhost:8080/HotelBackend/LoginServlet", {
        email: $("#username").val()
        , password: $("#password").val()
    }, function (data) {
        if (data.message == "OK") location.href = "hotels.html";
        else alert("Invalid credentials");
    });
}
function register() {
  nume="altceva";  $.post("http://localhost:8080/HotelBackend/RegisterServlet", {
        email: $("#username").val()
        , password: $("#password").val()
        , nume: $("#name").val()
    }, function (data) {
       alert("Registered Successfully");
    });
}
function search() {
    $.get("http://localhost:8080/HotelBackend/SearchHotelServlet", {
        destination: $("#destination").val()
        , checkin: $("#checkIn").val()
        , checkout: $("#checkOut").val()
        , nrRooms: $("#nrRooms").val()
    }, function (data) {
          var hotels="<table><tr><td>Hotel Name</td><td>Stars</td><td>Rating</td><td>City</td><td>Image</td></tr>";
       
       for(var i = 0; i<data.length; i++){
         hotels+="<tr><td>"+ data[i].hotelName + "</td>";
            hotels+="<td>"+ data[i].stars + "</td>";
           hotels+="<td>" + data[i].rating + "</td>";
           hotels+="<td>" + data[i].city + "</td>";
           hotels+="<td><img src='" + data[i].image + "' style='height:100px;width:100px'></td>";
           hotels+="</tr>";
           
       }
        hotels+="</table>";
        $("#hotels").html(hotels);
    });
}