package Enered.TestHibernate;

public class SubjectManager {

}
