package Enered.TestHibernate;

import java.util.ArrayList;
import java.util.List;

import org.hibernate.HibernateException;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

import test.Beans.Student;

public class StudentManager {
	private static SessionFactory factory;

	public StudentManager() {
		factory = new Configuration().configure().buildSessionFactory();
	}

	// public List<Student> listStudent() {
	// List<Student> students = new ArrayList<Student>();
	// Session session = factory.getCurrentSession();
	// Transaction transaction = null;
	// try {
	// transaction = session.beginTransaction();
	// students = session.createQuery("FROM Student").list();
	// for (Student stud : students) {
	// System.out.println("First name: " + stud.getFirstName());
	// System.out.println("Last name: " + stud.getLastName());
	// System.out.println("Clasa: " + stud.getClassID());
	//
	// }
	// transaction.commit();
	//
	// } catch (HibernateException e) {
	// System.out.println("AM CRAPAT");
	// transaction.rollback();
	// } finally {
	// session.close();
	// }
	//
	// return students;
	//
	// }

	public Student getbyID(Integer ID) {
		Student s = new Student();
		Session session = factory.getCurrentSession();
		Transaction transaction = null;
		try {
			transaction = session.beginTransaction();

			s = (Student) session.get(Student.class, ID);

			transaction.commit();

		} catch (HibernateException e) {
			System.out.println("AM CRAPAT");
			transaction.rollback();
		} finally {
			session.close();
		}

		return s;

	}

}