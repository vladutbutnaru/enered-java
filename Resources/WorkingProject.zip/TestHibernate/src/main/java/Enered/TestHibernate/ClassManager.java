package Enered.TestHibernate;

public class ClassManager {

}
