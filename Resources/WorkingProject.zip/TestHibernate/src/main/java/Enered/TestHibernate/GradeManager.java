package Enered.TestHibernate;

import java.util.ArrayList;
import java.util.List;

import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

import test.Beans.Grade;
import test.Beans.Student;

public class GradeManager {
	private static SessionFactory factory;

	public GradeManager() {
		factory = new Configuration().configure().buildSessionFactory();
	}

	public void listGrade() {
		List<Grade> grades = new ArrayList<Grade>();
		Session session = factory.getCurrentSession();
		Transaction transaction = null;
		StudentManager sm = new StudentManager();
		try {
			transaction = session.beginTransaction();
			grades = session.createQuery("FROM Grade G WHERE G.grade >= 5").list();

			for (Grade gr : grades) {
				Student s = sm.getbyID(gr.getStudentID());
				System.out.println("Student promovat " + s.getFirstName() + " " + s.getLastName());

			}
			transaction.commit();

		} catch (HibernateException e) {
			System.out.println("AM CRAPAT");
			transaction.rollback();
		} finally {
			session.close();
		}

	}

}