package Enered.TestHibernate;

import java.util.List;

/**
 * Hello world!
 *
 */
public class App {
	public static void main(String[] args) {
		GradeManager gm = new GradeManager();
		gm.listGrade();
	}
}
