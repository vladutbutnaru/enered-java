package ro.enered.bank.utils;

public class Contants {

	public static final int CLOSED = 0;
	public static final int ACTIVE = 1;
	public static final double pi = 3.14;
	
	public static final double dobanda = 1.2;
}
