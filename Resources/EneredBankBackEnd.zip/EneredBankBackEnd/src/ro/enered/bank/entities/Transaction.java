package ro.enered.bank.entities;

import java.sql.Date;

public class Transaction {
	private int ID;
	private int idPlatitor;
	private int idBeneficiar;
	private Date date;
	private double suma;
	private String valuta;
	private int status;
	private int idATM;
	
	public int getID() {
		return ID;
	}
	public void setID(int iD) {
		ID = iD;
	}
	public int getIdPlatitor() {
		return idPlatitor;
	}
	public void setIdPlatitor(int idPlatitor) {
		this.idPlatitor = idPlatitor;
	}
	public int getIdBeneficiar() {
		return idBeneficiar;
	}
	public void setIdBeneficiar(int idBeneficiar) {
		this.idBeneficiar = idBeneficiar;
	}
	public Date getDate() {
		return date;
	}
	public void setDate(Date date) {
		this.date = date;
	}
	public double getSuma() {
		return suma;
	}
	public void setSuma(double suma) {
		this.suma = suma;
	}
	public String getValuta() {
		return valuta;
	}
	public void setValuta(String valuta) {
		this.valuta = valuta;
	}
	public int getStatus() {
		return status;
	}
	public void setStatus(int status) {
		this.status = status;
	}
	public int getIdATM() {
		return idATM;
	}
	public void setIdATM(int idATM) {
		this.idATM = idATM;
	}
}
