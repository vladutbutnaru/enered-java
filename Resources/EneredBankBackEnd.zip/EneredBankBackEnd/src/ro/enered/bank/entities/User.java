package ro.enered.bank.entities;

public class User {
	private int ID;
	private String nume;
	private String prenume;
	private int cnp;
	private int varsta;
	private int admin;
	
	public String getFullName(){
		return nume + " " + prenume;
		
	}
	public int getID() {
		return ID;
	}

	public void setID(int iD) {
		ID = iD;
	}

	public String getPrenume() {
		return prenume;
	}

	public void setPrenume(String prenume) {
		this.prenume = prenume;
	}

	public int getCnp() {
		return cnp;
	}

	public void setCnp(int cnp) {
		this.cnp = cnp;
	}

	public int getVarsta() {
		return varsta;
	}

	public void setVarsta(int varsta) {
		this.varsta = varsta;
	}

	public int getAdmin() {
		return admin;
	}

	public void setAdmin(int admin) {
		this.admin = admin;
	}

	private String getNume() {
		return nume;
	}

	private void setNume(String nume) {
		this.nume = nume;
	}
}
