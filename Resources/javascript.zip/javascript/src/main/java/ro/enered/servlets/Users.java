package ro.enered.servlets;

import java.util.ArrayList;

public class Users {
	public static ArrayList<String> users = new ArrayList<String>();
	public static ArrayList<String> passwords = new ArrayList<String>();
}
