package ro.enered.servlets;


import java.io.IOException;
import java.util.ArrayList;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class DataServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	public DataServlet() {
		super();

	}

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		ArrayList<String> items = new ArrayList<String>();
		items.add("Papuci");
		items.add("Cocaina");
		items.add("Escobar");
		items.add("ViaMedici");
		items.add("Yonder");
		
		String itemsForJS = "";
		for(String item: items){
			itemsForJS+=item+",";
			
		}
		response.getWriter().print(itemsForJS);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

	

}
}
