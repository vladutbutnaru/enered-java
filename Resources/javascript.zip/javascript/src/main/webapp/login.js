function login(operation) {
	if(operation == 1){
	$.post("LoginServlet", {
		username : $("#user").val(),
		password : $("#password").val()

	}, function(data) {
		// callback
		if (data == "ok") {
			location.href = "home.html";
		} else {
			alert("Datele nu sunt corecte");

		}

	});
	}
	else{
	$.get("LoginServlet", {
		username : $("#user").val(),
		password : $("#password").val()

	}, function(data) {
		// callback
		alert("Inregistrat cu succes!");

	});
	}
}
