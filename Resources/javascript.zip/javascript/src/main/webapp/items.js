var loaded=0;
function getItems(){
	if(loaded==0){
	$.get("DataServlet",
			{},
			function(data){
				var items = data.split(",");
				for(var i = 0; i<items.length; i++){
					document.getElementById("items").innerHTML=
						document.getElementById("items").innerHTML
						+ " " + items[i];
					
				}
			}
			);
	
	
	loaded=1;
	}
	
	$("#items").show();
	$("#items").css("color","red");

}
function hideStuff(){
	$("#items").hide();
	
}