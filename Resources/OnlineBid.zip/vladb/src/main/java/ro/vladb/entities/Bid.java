package ro.vladb.entities;

public class Bid {
	
private int id;
private int value;
private int productID;
private String email;

public int getId() {
	return id;
}
public void setId(int id) {
	this.id = id;
}
public int getValue() {
	return value;
}
public void setValue(int value) {
	this.value = value;
}
public int getProductID() {
	return productID;
}
public void setProductID(int productID) {
	this.productID = productID;
}
public String getEmail() {
	return email;
}
public void setEmail(String email) {
	this.email = email;
}

}
