package ro.vladb.controllers;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import ro.vladb.entities.User;
import ro.vladb.utils.DBConnection;

public class UserController {
Connection c = DBConnection.getConnection();
public int login(User u){
	try {
		PreparedStatement ps = c.prepareStatement(""
				+ "SELECT * FROM Users WHERE Email=? AND"
				+ " Password=?");
		ps.setString(1, u.getEmail());
		ps.setString(2, u.getPassword());
		ResultSet rs = ps.executeQuery();
		if(rs.next()){
			return rs.getInt(1);
			
		}
		
		
	} catch (SQLException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	return -1;
	
}
}
