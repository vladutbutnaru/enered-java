package ro.vladb.controllers;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import ro.vladb.entities.Bid;
import ro.vladb.utils.DBConnection;

public class BidController {
Connection c = DBConnection.getConnection();

public void addBid(Bid b){
	try {
		PreparedStatement ps = 
				c.prepareStatement(
						"INSERT INTO Bids(Email,Value,ProductID)"
						+ " VALUES(?,?,?)");
		ps.setString(1, b.getEmail());
		ps.setInt(2, b.getValue());
		ps.setInt(3, b.getProductID());
		ps.executeUpdate();
	
	} catch (SQLException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	
	
}
}
