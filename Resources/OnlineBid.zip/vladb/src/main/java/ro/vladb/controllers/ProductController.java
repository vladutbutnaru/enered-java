package ro.vladb.controllers;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import ro.vladb.entities.Product;
import ro.vladb.utils.DBConnection;

public class ProductController {
	Connection c = DBConnection.getConnection();

	public ArrayList<Product> getProducts() {
		ArrayList<Product> products = new ArrayList<Product>();
		try {
			PreparedStatement ps = c.prepareStatement("SELECT * FROM Produse");
			ResultSet rs = ps.executeQuery();
			while (rs.next()) {
				Product p = new Product();
				p.setId(rs.getInt(1));
				p.setName(rs.getString(2));
				p.setUserID(rs.getInt(3));
				products.add(p);
			}

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return products;
	}

	public ArrayList<Product> getProductsByUserID(int id) {
		ArrayList<Product> products = new ArrayList<Product>();
		try {
			PreparedStatement ps = c.prepareStatement("SELECT * " + "FROM Produse WHERE CreatorID=?");
			ps.setInt(1, id);
			ResultSet rs = ps.executeQuery();
			while (rs.next()) {
				Product p = new Product();
				p.setId(rs.getInt(1));
				p.setName(rs.getString(2));
				p.setUserID(rs.getInt(3));
				products.add(p);
			}

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return products;
	}

	public void deleteProduct(int id) {
		PreparedStatement ps;
		try {
			ps = c.prepareStatement("DELETE FROM Produse WHERE ID=?");
			ps.setInt(1, id);
			ps.executeUpdate();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}
}
