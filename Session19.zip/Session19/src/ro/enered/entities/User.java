package ro.enered.entities;

public class User {
private int id;
private String nume;
private String prenume;
private int varsta;
public int getVarsta() {
	return varsta;
}
public void setVarsta(int varsta) {
	this.varsta = varsta;
}
public int getSex() {
	return sex;
}
public void setSex(int sex) {
	this.sex = sex;
}
private int sex;
public int getId() {
	return id;
}
public void setId(int id) {
	this.id = id;
}
public String getNume() {
	return nume;
}
public void setNume(String nume) {
	this.nume = nume;
}
public String getPrenume() {
	return prenume;
}
public void setPrenume(String prenume) {
	this.prenume = prenume;
}
public String getUsername() {
	return username;
}
public void setUsername(String username) {
	this.username = username;
}
public String getParola() {
	return parola;
}
public void setParola(String parola) {
	this.parola = parola;
}
private String username;
private String parola;
}
