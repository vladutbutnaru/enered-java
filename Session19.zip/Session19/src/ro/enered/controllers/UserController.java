package ro.enered.controllers;

import java.util.ArrayList;

import ro.enered.entities.User;
import ro.enered.utils.InitData;

public class UserController {
	public boolean checkLogin(User u) {
		InitData id = new InitData();

		ArrayList<User> users = id.getUsers();
		for (User u1 : users) {
			if (u.getUsername().equals(u1.getUsername()))
				if (u.getParola().equals(u1.getParola())){
					
					id.setCurrentUser(u1);
					
					
					return true;
					
				
				}
			
			
			
		}
		return false;
	}
	
	public void test(){
		InitData id = new InitData();
		User u = new User();
		id.addUser(u);
		InitData id2 = new InitData();
		
		
	}

}
