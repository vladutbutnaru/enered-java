package ro.enered.utils;

import java.util.ArrayList;
import ro.enered.entities.Relationship;
import ro.enered.entities.User;

public class InitData {
	private static ArrayList<User> users= new ArrayList<User>();
	private static ArrayList<Relationship> relatii = new ArrayList<Relationship>();
    private static User currentUser;
    public static ArrayList<User> getUsers() {
		return users;
	}

	public static void setUsers(ArrayList<User> users) {
		InitData.users = users;
	}

	public static ArrayList<Relationship> getRelatii() {
		return relatii;
	}

	public static void setRelatii(ArrayList<Relationship> relatii) {
		InitData.relatii = relatii;
	}

	public InitData() {
	
if(users.isEmpty()){
	

	
		User u1 = new User();
		User u2 = new User();
		
		u1.setId(1);
		u1.setNume("Vladuletz");
		u1.setParola("decenu");
		u1.setUsername("vlad");
		u2.setId(2);
		u2.setNume("Asu");
		u2.setParola("mergpejos");
		u2.setUsername("loverboy");
		users.add(u1);
		users.add(u2);
		Relationship rel = new Relationship();
		rel.setId(1);
		rel.setId1(1);
		rel.setId2(2);
		relatii.add(rel);
}
	}

	public void addUser(User u) {
		users.add(u);
	}

	public static User getCurrentUser() {
		return currentUser;
	}

	public static void setCurrentUser(User currentUser) {
		InitData.currentUser = currentUser;
	}

}
