package ro.enered.sesiune7;


public class Main {

	public static void main(String[] args) {
Menu menu= new Menu();
menu.startApp();
	}
}
