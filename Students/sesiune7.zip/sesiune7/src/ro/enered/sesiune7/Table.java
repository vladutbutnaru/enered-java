package ro.enered.sesiune7;

import java.util.ArrayList;

public class Table {
	private boolean available;
	private int nrMasa;
	ArrayList<User> users;// daca ai eraore dai pe eroare si alegi import
							// ...genereaza randul 3
	// constructorul incepe

	public Table(int nrMasa) {
		setnrMasa(nrMasa);// sau this.nrMasa=nrMasa
		users = new ArrayList<User>();
		setAvailable(true);// la inceput masa e libera
	}

	// cosntructorul se termina
	// getters and setteres
	public boolean isAvailable() {
		return available;
	}

	public void setAvailable(boolean available) {
		this.available = available;
	}

	public int getnrMasa() {
		return nrMasa;
	}

	public void setnrMasa(int nrMasa) {
		this.nrMasa = nrMasa;
	}

	// methoods start
	public void reserve(User u) {// u=userul o instasnta a User
		if(isAvailable()){
			//face o rezervare introducand userul
		users.add(u);
		//setam falg false
		setAvailable(false);
	//	mesajul de rezervare cu succes
		System.out.println("The table was resered successfully");
		}
		else {
			System.out.println("The table is already resered");
		}
		
		
	}

	public void leaveTable() {
setAvailable(true);

	}
	public void showHistory(){
		System.out.println("The table with nrMasa:" + getnrMasa()+ "had the following customers");//users e lisata si nua re nume predefinit
		for(int i=0; i<users.size(); i++){
			System.out.println(users.get(i).getName());//pentru a alege numele user-ului din lista
		}
		System.out.println();
	}

}
