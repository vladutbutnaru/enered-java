package ro.enered.sesiune7;

import java.util.ArrayList;
import java.util.Scanner;

public class Menu {// aici ai motorul
	// initial met Start
	public void startApp() {
		// instantiere mese
		Table table1 = new Table(1);
		Table table2 = new Table(2);
		Table table3 = new Table(3);
		Table table4 = new Table(4);
		// instantiere arrays
		ArrayList<Table> tables = new ArrayList<Table>();
		tables.add(table1);
		tables.add(table2);
		tables.add(table3);
		tables.add(table4);
		// instantiere user
		User user = new User();// instantiem clasa User
		// instantiere reader
		Scanner reader = new Scanner(System.in);
		// show menu
		showMenu();
		// option will save de current selection
		int option = reader.nextInt();
		// while user doesn't chose 6(exit)
		while (option != 6) {
			switch (option) {
			// display availb tables
			case 1:
				for (int i = 0; i < tables.size(); i++) {
					if (tables.get(i).isAvailable()) {
						System.out.println(tables.get(i).getnrMasa());
					}
				}

				break;
			case 2: // in cazul in care alege 2 il intrebam care este numele sau
					// de numarul de masa si facem rezervare
				System.out.println("What is your name?");
				String name= reader.next();
				User user2= new User();
				user2.setName(name);
				// intreb ce masa vrea
				System.out.println("Which table would you like?");
				// salvam raspunsul in chosenTable
				int chosenTable = reader.nextInt();
				for (int i = 0; i < tables.size(); i++) {
					if (tables.get(i).getnrMasa() == chosenTable) {
						tables.get(i).reserve(user2);
						
					}
				}
				break;
			case 3:
				System.out.println("What is your name?");
				user.setName(reader.nextLine());
				// intreb ce masa vrea
				System.out.println("Which table would you like?");
				// salvam raspunsul in chosenTable
				chosenTable = reader.nextInt();
				// cautam masa cu numarul alse in ArrayList tables
				for (int i = 0; i < tables.size(); i++) {
					//daca masa are numarul ales
					if (tables.get(i).getnrMasa() == chosenTable) {
						//eliberam masa
						tables.get(i).reserve(user);
						// aratam mesajul
						System.out.println(" Table is now free");

					}

				}
				break;
			case 4:
				
			int max=0;
			Table maxTable= new Table (8);
			
			for(int i=0; i<tables.size(); i++){
				//verificam care sunt mesele cu cei mai multi utilz
				if(tables.get(i).users.size()>max){
					
					max=tables.get(i).users.size();
					//salveaza instanta mesei cu cei mai multi 
					maxTable = tables.get(i);				
				}				
			
			//arata nr mesei cu cei mai multi
System.out.println(maxTable.getnrMasa());
			}
	
		break;
		case 5:
			for(int i=0;i<tables.size(); i++){
				//cerem istoricul
				tables.get(i).showHistory();
				
			}
			break;
			
			}
			showMenu();
			option= reader.nextInt();
			}


	}

	public void showMenu() {
		System.out.println("1. Customer - check free tables");
		System.out.println("2. Customer - reserve a table");
		System.out.println("3. Customer - leave restaurant");
		System.out.println("4. Admin - view most popular table");
		System.out.println("5. view each table history");
		System.out.println("6. Exit");

	}
}
