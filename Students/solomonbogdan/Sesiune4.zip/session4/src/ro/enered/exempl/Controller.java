package ro.enered.exempl;

public class Controller {
	
	public void callMethod(){
		Owner  o = new Owner();
		o.setDog(new Dog());
		o.setCat(new Cat("tom2","verde",4));
		o.walkAnimals(8);
	}

}
