package ro.enered.exempl;

public class Main {
	
	public static void main (String[] args){
		
		//Instantiere
		Cat pisica = new Cat("Garfield","orange",4);
		Owner gigel = new Owner();
		Dog dog = new Dog();
		Controller c = new Controller();
		int kilometers=12;
		Student cristi= new Student("Cristi",23);
		Student ion = new Student();
		ion.setNume("IOn");
		ion.setVarsta(62);
		System.out.println(cristi.Returneaza());
		System.out.println(ion.Returneaza());
		Colectiv c1 = new Colectiv();
		c1.setStudent1(cristi);
		c1.setStudent2(ion);
		c1.rcolectiv();
		
		//Apeluri si functii
		
		gigel.setCat(pisica);
		gigel.setDog(dog);
		pisica.talk();
		pisica.walk(kilometers);
		gigel.walkAnimals(6);
		c.callMethod();
		//pisica.setName("Garfield");
		pisica.suffix("ului");
		
		//Afisare
		
		System.out.println(pisica.suffix("ului"));
		System.out.println();
		
		
		
		
	}

}
