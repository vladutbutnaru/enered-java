package ro.enered.exempl;

public class Cat {

	String name , colour;
	int age;
	
	//Constructor
	
	public Cat(String name,String color , int age){
		setName(name);
		this.colour=color;
		this.age=age;
	}
	
	//Metoda talk
	public void talk(){
		System.out.println("meow");
	}
	public void walk(int km){
		System.out.println("The cat walked "+ km+ " km");
	}
	
	public String suffix(String sufix){
		return name+sufix;
	}
	
	public void setName(String name){
		
		this.name = name;
	
	}

	public String getColour() {
		return colour;
	}

	public void setColour(String colour) {
		this.colour = colour;
	}

	public int getAge() {
		return age;
	}

	public void setAge(int age) {
		this.age = age;
	}

	public String getName() {
		return name;
	}
	
}
