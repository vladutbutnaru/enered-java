package ro.enered.exempl;

public class Dog {
	
	String name ,color;
	int age;
	
	
	
	public void talk(){
		System.out.println("bark");
	}
	public void walk(int km){
		System.out.println("The dog walked "+ km+ " km");
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getColor() {
		return color;
	}
	public void setColor(String color) {
		this.color = color;
	}
	public int getAge() {
		return age;
	}
	public void setAge(int age) {
		this.age = age;
	}
	

}
