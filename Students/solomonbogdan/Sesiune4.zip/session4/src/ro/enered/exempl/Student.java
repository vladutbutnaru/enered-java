package ro.enered.exempl;

public class Student {
	
	String nume;
	int varsta;
	public String getNume() {
		return nume;
	}
	public void setNume(String nume) {
		this.nume = nume;
	}
	public int getVarsta() {
		return varsta;
	}
	public void setVarsta(int varsta) {
		this.varsta = varsta;
	}
	public Student(){
		
	}
	public Student(String nume,int varsta){
           this.nume=nume;
           this.varsta=varsta;
	}
	
    public String Returneaza (){
    	return "ma "+" numesc "+nume+" si "+" am "+varsta;
    }
    	
    }