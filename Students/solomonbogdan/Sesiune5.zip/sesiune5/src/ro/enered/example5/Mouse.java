package ro.enered.example5;

public class Mouse {

	
	int x;
	int y;
	public int getX() {
		return x;
	}
	public void setX(int x) {
		this.x = x;
	}
	public int getY() {
		return y;
	}
	public void setY(int y) {
		this.y = y;
	}
	
	public boolean canMoveLeft(Map matrix){
		char [][] map = matrix.getMap(); 
		if(map[x][y-1] == 'o' || map[x][y-1]=='c')
			
			return true;
		return false;
	}
		
		
	public boolean canMoveRight(Map matrix){
		char [][] map = matrix.getMap(); 
		if(map[x][y+1] == 'o'|| map[x][y+1]=='c')
			return true;
		return false;
	}
	public boolean canMoveUp(Map matrix){
		char [][] map = matrix.getMap(); 
		if(map[x-1][y] == 'o'|| map[x-1][y]=='c')
			return true;
		return false;
	}
	public boolean canMoveDown(Map matrix){
		char [][] map = matrix.getMap(); 
		if(map[x+1][y] == 'o'|| map[x+1][y-1]=='c')
			return true;
		return false;
	}
	public void moveLeft(Map matrix){
		
		char [][] map = matrix.getMap();
		
		if (canMoveLeft(matrix)){
			map[x][y]='-';
			map[x][--y]='m';
			matrix.setMap(map);
		}
		}
		public void moveRight(Map matrix){
			
			char [][] map = matrix.getMap();
			
			if (canMoveLeft(matrix)){
				map[x][y]='-';
				map[x][++y]='m';
				matrix.setMap(map);
			}
	}
			public void moveUp(Map matrix){
				
				char [][] map = matrix.getMap();
				
				if (canMoveLeft(matrix)){
					map[x][y]='|';
					map[--x][y]='m';
					matrix.setMap(map);
				}
			}
		
					
				public void moveDown(Map matrix){
					
					char [][] map = matrix.getMap();
					
					if (canMoveLeft(matrix)){
						map[x][y]='|';
						map[++x][y]='m';
						matrix.setMap(map);
						
					}
               
}
				public void find(Map matrix){
					char [][] map = matrix.getMap();
				
					for (int i =0;i<map.length;i++){
						for(int j=0;j<map.length;j++){
							if(map[i][j] =='m'){
								x=i;
								y=j;
							}
					}
				}
				}
		}