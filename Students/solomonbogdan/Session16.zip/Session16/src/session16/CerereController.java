/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package session16;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author Java3
 */
public class CerereController {
    
     DBConnection con= new DBConnection();
    Connection conn = con.getConnection();
    
    
    public ArrayList<Cerere> getAll(){
        
        ArrayList<Cerere> cereriList = new ArrayList<Cerere>();
        String query = "SELECT * FROM Cereri WHERE Status='Pending'";
        
        Cerere ce = new Cerere();
        try {
            Statement s = conn.createStatement();
            ResultSet rs = s.executeQuery(query);
            
            while(rs.next()){
                
                
                ce.setId(rs.getInt(0));
                ce.setIdCarte(rs.getInt(1));
                ce.setIdUser(rs.getInt(2));
                ce.setDataInceput(rs.getDate(3));
                ce.setNrZile(rs.getInt(4));
                ce.setStatus(rs.getString(5));
                cereriList.add(ce);
            }  
        
        } catch (SQLException ex) {
            Logger.getLogger(UserController.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        return cereriList;
    }
    
    public Cerere GetById (int id){
        
         String query = "SELECT * FROM Cereri WHERE ID="+id;
        Cerere cererenoua = new Cerere();
        try {
            
            Statement st = conn.createStatement();
            ResultSet rs = st.executeQuery(query);
            
            while(rs.next()){
                
                
                cererenoua.setId(rs.getInt(0));
                cererenoua.setIdCarte(rs.getInt(1));
                cererenoua.setIdUser(rs.getInt(2));
                cererenoua.setDataInceput(rs.getDate(3));
                cererenoua.setNrZile(rs.getInt(4));
                cererenoua.setStatus(rs.getString(5));
               
                
                
            }
        } catch (SQLException ex) {
            Logger.getLogger(CarteController.class.getName()).log(Level.SEVERE, null, ex);
        }
        return cererenoua;
}
    public void add(Cerere cr){
        try{
        String query = "INSERT INTO Cereri"+ "(idCarte,idUser,dataInceput," + " nrZile,Status)"+ "VALUES ("+cr.getIdCarte()+","+cr.getIdUser()+"," + cr.getNrZile()+"," + cr.getStatus()+")";
        
         
             
             
             Statement s = conn.createStatement();
             s.executeUpdate(query);
             
             
             
         } catch (SQLException ex) {
             Logger.getLogger(CerereController.class.getName()).log(Level.SEVERE, null, ex);
         }
          
        }
     public void aprobareCerere(Cerere c){
         
         
         try{
             
             
         PreparedStatement pst;
         
         pst=conn.prepareStatement("update Cereri set Status = 'Approved' where ID=?");
         
         pst.setInt(1, c.getId());
             
             
         } catch (SQLException ex) {
             Logger.getLogger(CerereController.class.getName()).log(Level.SEVERE, null, ex);
         }
         
     }
     
     public void respingeCerere(Cerere c){
         
         String query = "update Cereri set Status = 'Rejected' where Id = "+ c.getId();
         
         try {
             
             Statement s = conn.createStatement();
             s.executeUpdate(query);
             
         } catch (SQLException ex) {
             Logger.getLogger(CerereController.class.getName()).log(Level.SEVERE, null, ex);
         }
         
     }
    }



