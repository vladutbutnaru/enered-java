package ro.enered.test;

public class SayHello {
	
	public String hello(){
		return "Salut";
	}

}
