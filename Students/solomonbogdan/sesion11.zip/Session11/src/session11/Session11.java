/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package session11;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.logging.Level;
import java.util.logging.Logger;


public class Session11{
    
    
    
public static void main(String[] args) throws SQLException{


DBConnection connectionFactory = new DBConnection();
Connection c = (Connection) connectionFactory.getConnection();



    try {
        
    
       Statement  s = c.createStatement();
    
       String query = "SELECT * FROM Produse";
       String insertQuery = "INSERT INTO Produse(Nume,UM,Cantitate,Categorie) VALUES ('Ceapa')";
        s.executeUpdate(insertQuery);
        ResultSet rs = s.executeQuery(query);
       while(rs.next()){
        System.out.println(rs.getString("Nume"));
        System.out.println(rs.getString("UM"));
        System.out.println(rs.getInt("Cantitate"));
        System.out.print(rs.getDate("DataCreare"));
    
       }
    }catch (SQLException ex) {
        Logger.getLogger(Session11.class.getName()).log(Level.SEVERE, null, ex);
    }
        
        


}





}