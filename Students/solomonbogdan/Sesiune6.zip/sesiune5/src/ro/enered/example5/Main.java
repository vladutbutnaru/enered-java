package ro.enered.example5;

/*public class Main {
	
public static void main(String[] args){
	
	
	char[][] map= new char[15][15];
	
	for (int i = 0; i < map.length; i++) {
		for (int j = 0; j < map.length; j++) {
			map[i][j] = 'o';
			if (i==7 &&j==12) 
				map[i][j]='m';//mouse
			if(i==2 && j==3)
				map[i][j]='c';//cascaval
			if(i==5 && j==4)
				map[i][j]='x';//obstacol
			
				
			
			
		}
		
	}
	Map harta1 = new Map();
	Mouse soarece = new Mouse();
	Cheese cascaval=new Cheese();
	Engine controller = new Engine();
	controller.play(cascaval, harta1, soarece);
	
 	harta1.setMap(map);//setam matricea
	harta1.display();
	System.out.println();
	soarece.find(harta1);
	cascaval.find(harta1);
	
	

System.out.println();
    harta1.display();
}
}
*/
public class Main{
	
  public static void main(String[] args){
	  
	  
    
   
    Mouse soarece = new Mouse();
    Cheese cascaval = new Cheese();
    Map harta1 = new Map();
    Engine controller = new Engine();
    harta1 = controller.generateRandomMap();
    soarece.find(harta1);
    cascaval.find(harta1);
    harta1.display();
    
    
    
    
   // controller.play(cascaval, harta1, soarece);
   controller.playAvoidingObstacles(cascaval,harta1, soarece);
    System.out.println();
    harta1.display();
    
    
  }
}
