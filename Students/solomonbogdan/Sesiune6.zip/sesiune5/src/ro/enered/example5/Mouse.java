package ro.enered.example5;

/*public class Mouse {

	
	int x;
	int y;
	public int getX() {
		return x;
	}
	public void setX(int x) {
		this.x = x;
	}
	public int getY() {
		return y;
	}
	public void setY(int y) {
		this.y = y;
	}
	
	public boolean canMoveLeft(Map matrix){
		char [][] map = matrix.getMap(); 
		if(map[x][y-1] == 'o' || map[x][y-1]=='c'|| map[x][y-1] == '-' || map[x][y-1]=='|')
			
			return true;
		return false;
	}
		
		
	public boolean canMoveRight(Map matrix){
		char [][] map = matrix.getMap(); 
		if(map[x][y+1] == 'o'|| map[x][y+1]=='c'|| map[x][y+1] == '-' || map[x][y+1]=='|')
			return true;
		return false;
	}
	public boolean canMoveUp(Map matrix){
		char [][] map = matrix.getMap(); 
		if(map[x-1][y] == 'o'|| map[x-1][y]=='c'||map[x-1][y] == '-' || map[x-1][y]=='|')
			return true;
		return false;
	}
	public boolean canMoveDown(Map matrix){
		char [][] map = matrix.getMap(); 
		if(map[x+1][y] == 'o'|| map[x+1][y-1]=='c'|| map[x+1][y] == '-' || map[x+1][y]=='|')
			return true;
		return false;
	}
	public void moveLeft(Map matrix){
		
		char [][] map = matrix.getMap();
		
		if (canMoveLeft(matrix)){
			map[x][y]='-';
			map[x][--y]='m';
			matrix.setMap(map);
		}
		}
		public void moveRight(Map matrix){
			
			char [][] map = matrix.getMap();
			
			if (canMoveRight(matrix)){
				map[x][y]='-';
				map[x][++y]='m';
				matrix.setMap(map);
			}
	}
			public void moveUp(Map matrix){
				
				char [][] map = matrix.getMap();
				
				if (canMoveUp(matrix)){
					map[x][y]='|';
					map[--x][y]='m';
					matrix.setMap(map);
				}
			}
		
					
				public void moveDown(Map matrix){
					
					char [][] map = matrix.getMap();
					
					if (canMoveDown(matrix)){
						map[x][y]='|';
						map[++x][y]='m';
						matrix.setMap(map);
						
					}
               
}
				public void find(Map matrix){
					char [][] map = matrix.getMap();
				
					for (int i =0;i<map.length;i++){
						for(int j=0;j<map.length;j++){
							if(map[i][j] =='m'){
								x=i;
								y=j;
							}
					}
				}
				}
		}
	*/
	public class Mouse {

	    int x;
	    int y;

	    public int getX() {
	        return this.x;
	    }

	    public void setX(int x) {
	        this.x = x;
	    }

	    public int getY() {
	        return this.y;
	    }

	    public void setY(int y) {
	        this.y = y;
	    }

	    public boolean canMoveLeft(Map matrix) {
	        char[][] map = matrix.getMap();
	        if ((map[this.x][(this.y - 1)] == 'o') || (map[this.x][(this.y - 1)] == 'c')|| (map[this.x][(this.y - 1)] == '-')|| (map[this.x][(this.y - 1)] == '|')) {
	            return true;
	        }
	        return false;
	    }

	    public boolean canMoveRight(Map matrix) {
	        char[][] map = matrix.getMap();
	        if ((map[this.x][(this.y + 1)] == 'o') || (map[this.x][(this.y + 1)] == 'c')|| (map[this.x][(this.y + 1)] == '-')|| (map[this.x][(this.y + 1)] == '|')) {
	            return true;
	        }
	        return false;
	    }

	    public boolean canMoveUp(Map matrix) {
	        char[][] map = matrix.getMap();
	        if ((map[(this.x - 1)][this.y] == 'o') || (map[(this.x - 1)][this.y] == 'c')|| (map[(this.x - 1)][this.y] == '-')|| (map[(this.x - 1)][this.y] == '|')) {
	            return true;
	        }
	        return false;
	    }

	    public boolean canMoveDown(Map matrix) {
	        char[][] map = matrix.getMap();
	        if ((map[(this.x + 1)][this.y] == 'o') || (map[(this.x + 1)][this.y] == 'c')|| (map[(this.x + 1)][this.y] == '-')|| (map[(this.x + 1)][this.y] == '|')) {
	            return true;
	        }
	        return false;
	    }

	    public void moveLeft(Map matrix) {
	        char[][] map = matrix.getMap();
	        if (canMoveLeft(matrix)) {
	            map[this.x][this.y] = '-';

	            map[this.x][(--this.y)] = 'm';
	            matrix.setMap(map);
	        }
	    }

	    public void moveRight(Map matrix) {
	        char[][] map = matrix.getMap();
	        if (canMoveRight(matrix)) {
	            map[this.x][this.y] = '-';
	            map[this.x][(++this.y)] = 'm';
	            matrix.setMap(map);
	        }
	    }

	    public void moveUp(Map matrix) {
	        char[][] map = matrix.getMap();
	        if (canMoveUp(matrix)) {
	            map[this.x][this.y] = '|';
	            map[(--this.x)][this.y] = 'm';
	            matrix.setMap(map);
	        }
	    }

	    public void moveDown(Map matrix) {
	        char[][] map = matrix.getMap();
	        if (canMoveDown(matrix)) {
	            map[this.x][this.y] = '|';
	            map[(++this.x)][this.y] = 'm';
	            matrix.setMap(map);
	        }
	    }

	    public void find(Map matrix) {
	        char[][] map = matrix.getMap();
	        for (int i = 0; i < map.length; i++) {
	            for (int j = 0; j < map.length; j++) {
	                if (map[i][j] == 'm') {
	                    this.x = i;
	                    this.y = j;
	                }
	            }
	        }

	    }

	}
