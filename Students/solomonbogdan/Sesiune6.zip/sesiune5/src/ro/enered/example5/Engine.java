package ro.enered.example5;

import java.util.Random;

public class Engine {
	
	
	public void play(Cheese cascaval , Map harta1 , Mouse soarece){
		
		while (!cascaval.isFound(harta1)){
			if(cascaval.getX() > soarece.getX()){
				soarece.moveDown(harta1);
			if(cascaval.getX()<soarece.getX()){
				soarece.moveUp(harta1);
			if(cascaval.getX()==soarece.getX()){
				if(cascaval.getY()>soarece.getY()){
					soarece.moveRight(harta1);
			    if(cascaval.getY()<soarece.getY()){
			    	soarece.moveLeft(harta1);
			    
			}
		}
	}
		}
	}
		}
	}
	
	public void playAvoidingObstacles(Cheese cascaval, Map harta1, Mouse soarece) {
		
		
		  while (!cascaval.isFound(harta1)) {
		   if (cascaval.getX() > soarece.getX()) {
		    while (soarece.canMoveDown(harta1) == false) {
		     if (soarece.canMoveLeft(harta1)) {
		      soarece.moveLeft(harta1);
		      if(soarece.canMoveDown(harta1) == true){
		       break;
		      }
		     } else {
		      if (soarece.canMoveRight(harta1)) {
		       soarece.moveRight(harta1);
		       if(soarece.canMoveDown(harta1) == true){
		        break;
		       }
		      }
		     }
		    }
		    soarece.moveDown(harta1);
		   }
		   if (cascaval.getX() < soarece.getX()) {
		    while (soarece.canMoveUp(harta1) == false) {
		     if (soarece.canMoveLeft(harta1)) {
		      soarece.moveLeft(harta1);
		      if(soarece.canMoveUp(harta1) == true){
		       break;
		      }
		     } else {
		      if (soarece.canMoveRight(harta1)) {
		       soarece.moveRight(harta1);
		       if(soarece.canMoveUp(harta1) == true){
		        break;
		       }
		      }
		     }
		    }
		    soarece.moveUp(harta1);
		   }
		   if (cascaval.getX() == soarece.getX()) {
		    if (cascaval.getY() > soarece.getY()) {
		    	
		    	while(soarece.canMoveRight(harta1)==false){
		    		
		    		if(soarece.canMoveUp(harta1)){
		    			soarece.moveUp(harta1);
		    			if(soarece.canMoveRight(harta1)==true)
break;
		    		}
		    		else
		    			if(soarece.canMoveDown(harta1)){
		    			soarece.moveDown(harta1);
		    			if(soarece.canMoveRight(harta1)==true)
break;
		    		}
		    	}
		     soarece.moveRight(harta1);
		    }
		    if (cascaval.getY() < soarece.getY()) {
		    	
while(soarece.canMoveLeft(harta1)==false){
		    		
		    		if(soarece.canMoveUp(harta1)){
		    			soarece.moveUp(harta1);
		    			if(soarece.canMoveLeft(harta1)==true)
break;
		    		}
		    		else
		    			if(soarece.canMoveDown(harta1)){
		    			soarece.moveDown(harta1);
		    			if(soarece.canMoveLeft(harta1)==true)
break;
		    		}
		    	}
		    	
		    	
		     soarece.moveLeft(harta1);
		    }
		   }
		

		  }
		 }
	   public Map generateRandomMap(){
		   Map m = new Map();
		   Random random = new Random();
		   int a = random.nextInt(15);
		   
		   char[][] map = new char[15][15];
		    for (int i = 0; i < map.length; i++) {
		      for (int j = 0; j < map.length; j++)
		      {
		        map[i][j] = 'o';
		        if (i == new Random().nextInt(15) && (j == new Random().nextInt(15))) {
		          map[i][j] = 'c';
		        }
		        if (i == new Random().nextInt(15) && (j == new Random().nextInt(15))) {
		          map[i][j] = 'm';
		        }
		        if (i == new Random().nextInt(15) && (j == new Random().nextInt(15))) {
		          map[i][j] = 'x';
		        }
		        if (i == new Random().nextInt(15) && (j == new Random().nextInt(15))) {
		            map[i][j] = 'x';
		          }
		        if (i == new Random().nextInt(15) && (j == new Random().nextInt(15))) {
		            map[i][j] = 'x';
		          }
		       
		       
		      }
		    }
		    
		    m.setMap(map);
		    return m;
		  
		   
		   
	   }
				}
	
