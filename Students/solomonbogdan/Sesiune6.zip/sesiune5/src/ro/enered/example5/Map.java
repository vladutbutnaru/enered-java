package ro.enered.example5;

public class Map {
	
	char[][] map = new char [15][15];

	public char[][] getMap() {
		return map;
	}

	public void setMap(char[][] map) {
		this.map = map;
	}
	
	public void display(){
		for (int i = 0; i < map.length; i++) {
			for (int j = 0; j < map.length; j++) {
				
				System.out.print(map[i][j]+" ");
				
			}
			System.out.println();
		}
	}

}
