/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package session12;

/**
 *
 * @author Java3
 */
public class Categorie {
    
    private int mid;
    private String numeCategorie;
    
    
    
    

    

    public void setMid(int mid) {
        this.mid = mid;
    }

    public String getNumeCategorie() {
        return numeCategorie;
    }

    public void setNumeCategorie(String numeCategorie) {
        this.numeCategorie = numeCategorie;
    }

    int getMid() {
        return mid;
    }
    
    
    
    
}
