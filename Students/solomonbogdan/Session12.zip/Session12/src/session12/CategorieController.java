/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package session12;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author Java3
 */
public class CategorieController implements CRUDable{

    @Override
    public void create(Object a) {
        DBConnection con = new DBConnection();
        Connection c= con.getConnection();
        Categorie cat = (Categorie)a;
        
        
        try {
            
           PreparedStatement p = c.prepareStatement("INSERT INTO Categorii(Nume) "+ "VALUES (?)");
            p.setString(1,cat.getNumeCategorie());
            p.execute();
            
        } catch (SQLException ex) {
            Logger.getLogger(CategorieController.class.getName()).log(Level.SEVERE, null, ex);
        }
       
    }

    @Override
    public void update(Object a) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public void delete(Object a) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public ArrayList<String> read() {
         throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools 
        
        
    }
    
}
