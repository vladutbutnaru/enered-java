package ro.enered.controllers;

import java.util.ArrayList;
import ro.enered.entities.Student;


public class StudentController {

	
	
	private ArrayList<Student> students;
	
	public StudentController(){
		
		students = new ArrayList<Student>();
		Student s1 = new Student("vlad","pass");
		Student s2 = new Student("ion","pass");
		Student s3 = new Student("marcel","pass12");
		
		students.add(s1);
		students.add(s2);
		students.add(s3);
	}
	
	public boolean checkLogin(Student s){
		
		for(Student i: students){
			if(i.getNume().equals(s.getNume())&& i.getPassword().equals(s.getPassword()))
				return true;
		}
		return false;
	}

}
