function auth(){
	
	var name= document.getElementById("nume").value;
	var pass= document.getElementById("parola").value;
	
	$.post("LoginServlet", {name:name , pass:pass},function(data){})
	
	
	if(data=="OK"){
		location.href="http://google.ro";
	}else{
		alert("Nu-i bine!!")
	}
}