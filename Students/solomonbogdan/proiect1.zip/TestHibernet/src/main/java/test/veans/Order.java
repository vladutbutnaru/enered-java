package test.veans;

public class Order {
	
	private int id;
	private int clientId;
	private int produsId;
	
	
	
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public int getClientId() {
		return clientId;
	}
	public void setClientId(int client) {
		this.clientId = client;
	}
	public int getProdusId() {
		return produsId;
	}
	public void setProdusId(int produs) {
		this.produsId = produs;
	}
	
	
	

}
