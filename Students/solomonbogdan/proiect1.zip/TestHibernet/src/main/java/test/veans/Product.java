package test.veans;

public class Product {
	
	private int id;
	private String numeProd;
	
	
	
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getNumeProd() {
		return numeProd;
	}
	public void setNumeProd(String numeProd) {
		this.numeProd = numeProd;
	}
	
	
	

}
