package Enered.TestHibernet;

import java.util.ArrayList;
import java.util.List;

import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;


import test.veans.Product;

public class ProductManager {
	
	private static SessionFactory factory;
	
	public ProductManager(){
		
		factory = new Configuration().configure().buildSessionFactory();
	}
	
	public Integer addProduct(Product prd){
		
		Session session = factory.getCurrentSession();
		
		Transaction transaction = null;
		
		Integer productID=null;
		
		try{
			transaction = session.beginTransaction();
			productID = (Integer) session.save(prd);
			
			
			
		}
		catch (HibernateException e){
			
		System.out.println("aM CRAPAT ");
			
			transaction.rollback();
		}	
			finally{
				session.close();
			}
			
		
		
		return productID;
	}
	public List<Product> listProducts(){
	
		List<Product> products = new ArrayList<Product>();
	Session session = factory.getCurrentSession();
	
	Transaction transaction = null;
	
	try{
		   transaction = session.beginTransaction();
		   products = session.createQuery("FROM  Produs").list();
		   for(Product e : products){
		    System.out.println("Produs : " + e.getNumeProd());
		    
		   }
		  }
		  catch(HibernateException e){
		   System.out.println("AM CRAPAT");
		   transaction.rollback();   
		  }  
		  finally{
		   session.close();
		  }
	return products;
	
	}
	
	
	public void deleteProduct(Product p){
        Session session = factory.getCurrentSession();
		
		Transaction transaction = null;
		
		
		
		try{
			transaction = session.beginTransaction();
			p= (Product) session.get(Product.class, p.getId());
			
			session.delete(p);
			
		}
		catch (HibernateException ex){
			
		System.out.println("aM CRAPAT ");
			
			transaction.rollback();
		}	
			finally{
				session.close();
			}
}
}
