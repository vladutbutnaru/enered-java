package Enered.TestHibernet;

import java.util.ArrayList;
import java.util.List;

import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;


import test.veans.User;

public class UserManager {
	
	private static SessionFactory factory;
	
	public UserManager(){
		
		factory = new Configuration().configure().buildSessionFactory();
	}
	
	public Integer addUser(User emp){
		
		Session session = factory.getCurrentSession();
		
		Transaction transaction = null;
		
		Integer userID=null;
		
		try{
			transaction = session.beginTransaction();
			userID = (Integer) session.save(emp);
			
			
			
		}
		catch (HibernateException e){
			
		System.out.println("aM CRAPAT ");
			
			transaction.rollback();
		}	
			finally{
				session.close();
			}
			
		
		
		return userID;
	}
	public List<User> listUsers(){
	
		List<User> 	users = new ArrayList<User>();
	Session session = factory.getCurrentSession();
	
	Transaction transaction = null;
	
	try{
		   transaction = session.beginTransaction();
		   users = session.createQuery("FROM User").list();
		   for(User e : users){
		    System.out.println("Name: " + e.getNume());
		    
		   }
		  }
		  catch(HibernateException e){
		   System.out.println("AM CRAPAT");
		   transaction.rollback();   
		  }  
		  finally{
		   session.close();
		  }
	return users;
	
	}
	
	public void updateUser(User e){
        Session session = factory.getCurrentSession();
		
		Transaction transaction = null;
		
		
		
		try{
			transaction = session.beginTransaction();
			e= (User) session.get(User.class, e.getId());
			
			session.update(e);
			
		}
		catch (HibernateException ex){
			
		System.out.println("aM CRAPAT ");
			
			transaction.rollback();
		}	
			finally{
				session.close();
			}
		
	}
	public void deleteUser(User e){
        Session session = factory.getCurrentSession();
		
		Transaction transaction = null;
		
		
		
		try{
			transaction = session.beginTransaction();
			e= (User) session.get(User.class, e.getId());
			
			session.delete(e);
			
		}
		catch (HibernateException ex){
			
		System.out.println("aM CRAPAT ");
			
			transaction.rollback();
		}	
			finally{
				session.close();
			}
}
}
