package Enered.TestHibernet;

import test.veans.User;
import test.veans.Product;
import test.veans.Order;

/**
 * Hello world!
 *
 */
public class App 
{
    public static void main( String[] args )
    {
       UserManager um = new UserManager();
       OrderManager om= new OrderManager();
       ProductManager pm = new ProductManager();
       
        User e = new User();
        
        Product p = new Product();
        
        Order o = new Order();
        
        
        e.setNume("GOGAIE");
       
        p.setNumeProd("mamaliga");
       
        o.setId(60);
        
        
         User e1 = new User();
        
        Product p1 = new Product();
        
        Order o1 = new Order();
        
        
        e.setNume("Nebun");
       
        p.setNumeProd("sarmale");
       
        o.setId(61);
        
        
        
  
        System.out.println(um.addUser(e));
        System.out.println(um.addUser(e1));
       
        um.addUser(e); 
        um.addUser(e1);
        
        
        om.addOrder(o);
        om.addOrder(o1);
        
        pm.addProduct(p);
        pm.addProduct(p1);
       
        um.listUsers();
        pm.listProducts();
        om.listOrders();
        

    }
}
