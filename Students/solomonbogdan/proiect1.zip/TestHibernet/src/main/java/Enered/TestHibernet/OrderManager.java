package Enered.TestHibernet;

import java.util.ArrayList;
import java.util.List;

import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;


import test.veans.Order;

public class OrderManager {
	
	private static SessionFactory factory;
	
	public OrderManager(){
		
		factory = new Configuration().configure().buildSessionFactory();
	}
	
	public Integer addOrder(Order ord){
		
		Session session = factory.getCurrentSession();
		
		Transaction transaction = null;
		
		
		Integer orderID = null;
		
		try{
			transaction = session.beginTransaction();
			
			orderID = (Integer) session.save(ord);
			
		}
		catch (HibernateException e){
			
		System.out.println("aM CRAPAT ");
			
			transaction.rollback();
		}	
			finally{
				session.close();
			}
			
		
		
		return orderID;
	}
	public List<Order> listOrders(){
	
		List<Order> 	orders = new ArrayList<Order>();
	Session session = factory.getCurrentSession();
	
	Transaction transaction = null;
	
	try{
		   transaction = session.beginTransaction();
		  orders = session.createQuery("FROM Order").list();
		   for(Order o : orders){
		    
		    System.out.print(" Client: " + o.getClientId());
		    System.out.println("Produs: " + o.getProdusId());
		   }
		  }
		  catch(HibernateException e){
		   System.out.println("AM CRAPAT");
		   transaction.rollback();   
		  }  
		  finally{
		   session.close();
		  }
	return orders;
	
	}
	
	
	public void deleteOrder(Order o){
        Session session = factory.getCurrentSession();
		
		Transaction transaction = null;
		
		
		
		try{
			transaction = session.beginTransaction();
			o= (Order) session.get(Order.class, o.getId());
			
			session.delete(o);
			
		}
		catch (HibernateException ex){
			
		System.out.println("aM CRAPAT ");
			
			transaction.rollback();
		}	
			finally{
				session.close();
			}
}
}