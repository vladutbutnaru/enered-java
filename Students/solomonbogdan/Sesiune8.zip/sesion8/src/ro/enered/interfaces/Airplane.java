package ro.enered.interfaces;

public class Airplane implements Countable{
	
	private int numOfPlanes;

	public int getNumOfPlanes() {
		return numOfPlanes;
	}

	public void setNumOfPlanes(int numOfPlanes) {
		this.numOfPlanes = numOfPlanes;
	}

	@Override
	public int count() {
		// TODO Auto-generated method stub
		return numOfPlanes;
	}
	
	

}
