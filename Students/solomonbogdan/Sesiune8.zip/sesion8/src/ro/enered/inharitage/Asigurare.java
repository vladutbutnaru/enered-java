package ro.enered.inharitage;

public class Asigurare extends Masina{
	
	private String expire;

	public String getExpire() {
		return expire;
	}

	public void setExpire(String expire) {
		this.expire = expire;
	}
//OVERLOADING
	public void pay(){
		System.out.println("RCA-ul costa 300 RON");
	}
	
	public void pay(String casco){
		System.out.println(casco + " -ul costa 700 RON in plus");
	}

}
