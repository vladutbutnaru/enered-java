package ro.enered.inharitage;

public class Asigurator extends Masina{
	
	private String nume;
	public Object set;

	public String getNume() {
		return nume;
	}

	public void setNume(String nume) {
		this.nume = nume;
	}
	
	

}
