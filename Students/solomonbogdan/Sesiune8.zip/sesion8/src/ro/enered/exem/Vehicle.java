package ro.enered.exem;

public class Vehicle {
	
	private int numOfWheels;
	public int getNumOfWheels() {
		return numOfWheels;
	}
	public void setNumOfWheels(int numOfWheels) {
		this.numOfWheels = numOfWheels;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public boolean isHasWheels() {
		return hasWheels;
	}
	public void setHasWheels(boolean hasWheels) {
		this.hasWheels = hasWheels;
	}
	private String name;
	private boolean hasWheels;

}
