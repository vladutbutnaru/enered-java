package ro.enered.exem;

import ro.enered.inharitage.Asigurare;
import ro.enered.inharitage.Asigurator;
import ro.enered.interfaces.Airplane;
import ro.enered.interfaces.ProdusAlimentar;
import ro.enered.interfaces.ProdusNealimentar;

public class Main {
	
	
	public static void main(String[] args){
		
		Cat garfield = new Cat();
		garfield.setColor("orange");
		garfield.setMammal(true);
		garfield.miauna();
		garfield.miauna(6);
		Fish goldfish = new Fish();
		goldfish.setColor("gold");
		goldfish.swim();
		Audi a = new Audi("Audi");
		System.out.println(a.getBrand());
		Bycicle pegasus = new Bycicle();
		pegasus.setHasBell(true);
		Airplane boeing = new Airplane();
		boeing.setNumOfPlanes(10);
		System.out.println(boeing.count());
		ProdusAlimentar bere = new ProdusAlimentar();
		ProdusNealimentar clor = new ProdusNealimentar();
		bere.setPrice(3.5);
		clor.setPrice(2.1);
		System.out.println("The price of beer " + bere.calculatePrice());
		System.out.println("The price of clor " + clor.calculatePrice());
		
		Asigurare asigurare = new Asigurare();
		Asigurator asirom = new Asigurator();
		asigurare.setColor("green");
		asigurare.setExpire("12/12/2009");
		asigurare.setNrAuto("is-09-bma");
		asigurare.pay();
		asigurare.pay("casco");
		System.out.println(asigurare.getExpire());
		
	}

}
