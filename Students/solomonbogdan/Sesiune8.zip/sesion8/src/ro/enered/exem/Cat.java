package ro.enered.exem;

public class Cat extends Animal{
	
	public void miauna(){
		
		if(super.isMammal())
			System.out.println("The mammal with color " + super.getColor() + " says meow");
		
		else 
			
		System.out.println("The cat with color " + super.getColor() + " says meow");
				 
	}
	
	public void miauna(int numOfTimes){
		for (int i = 0; i<numOfTimes; i++){
			System.out.println("The cat with color " + super.getColor() + " says miau");
		}
	}
	

}
