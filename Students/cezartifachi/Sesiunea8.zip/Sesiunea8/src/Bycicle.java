
public class Bycicle extends Vehicle{
private boolean hasBell;

public boolean isHasBell() {
	return hasBell;
}

public void setHasBell(boolean hasBell) {
	this.hasBell = hasBell;
}

}
