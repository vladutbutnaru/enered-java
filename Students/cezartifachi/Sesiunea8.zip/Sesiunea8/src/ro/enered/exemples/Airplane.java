package ro.enered.exemples;

public class Airplane implements Countable {
private int numOfAirplanes;	

	public int getNumOfAirplanes() {
	return numOfAirplanes;
}

public void setNumOfAirplanes(int numOfAirplanes) {
	this.numOfAirplanes = numOfAirplanes;
}

	@Override
	public int count() {
		
		return numOfAirplanes;
	}

}
