package ro.enered.exemples;

public interface tva {
public double calculatePrice();

}
