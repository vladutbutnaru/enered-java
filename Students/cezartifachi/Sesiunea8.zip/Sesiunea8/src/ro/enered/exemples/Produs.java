package ro.enered.exemples;

public class Produs {
private double price;

public double getPrice() {
	return price;
}

public void setPrice(double price) {
	this.price = price;
}

}
