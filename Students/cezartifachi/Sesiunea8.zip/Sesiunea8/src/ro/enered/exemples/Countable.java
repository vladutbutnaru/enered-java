package ro.enered.exemples;

public interface Countable {
public int count();
	

}
