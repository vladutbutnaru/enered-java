package ro.enered.exemples;

public class ProdusAlimentar extends Produs implements tva {


	@Override
	public double calculatePrice(){
	
	return super.getPrice()+super.getPrice()*0.09;
	
}
}
