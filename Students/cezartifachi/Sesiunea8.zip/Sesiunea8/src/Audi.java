
public class Audi extends Car{
public Audi (String brand){
	super.setBrand(brand);
	
}
	
}
