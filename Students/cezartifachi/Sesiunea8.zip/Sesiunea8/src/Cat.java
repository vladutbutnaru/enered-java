
public class Cat extends Animal {
public void miauna(){
	//daca este mamifer, atunci afisam "The mammal with color....
	if(super.isMammal())
	System.out.println("The mammal with color: " + super.getColor() + " says miau");
	else
		System.out.println("The cat with color: " + super.getColor() + " says miau");
	
	
}
public void miauna(int numOfTimes){
	for(int i =0; i<numOfTimes; i++){
		System.out.println("The cat with color " + super.getColor() + " says miau");
		/**sau
		/public void miauna(int numOfTimes){
		System.out.println("The cat with color " + super.getColor() + num OfTimes + " says miau");
		*/
	}
}
}
