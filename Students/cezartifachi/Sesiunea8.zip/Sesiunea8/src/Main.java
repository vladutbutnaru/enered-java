import ro.enered.exemples.Airplane;
import ro.enered.exemples.ProdusAlimentar;
import ro.enered.exemples.ProdusNealimentar;
import ro.enered.inheritance.Asigurare;
import ro.enered.inheritance.Asigurator;

public class Main {

public static void main(String[] args) {
	Cat garfield = new Cat();
	garfield.setColor("orange");
	garfield.setMammal(true);
	garfield.miauna();
	garfield.miauna(6);
	Fish goldFish = new Fish();
	goldFish.setColor("gold");
	goldFish.swim();
	Audi a = new Audi("Audi");
	System.out.println(a.getBrand());
	Bycicle pegas = new Bycicle();
	pegas.setHasBell(true);
	//interfaces
	Airplane boeing = new Airplane();
	boeing.setNumOfAirplanes(10);
	System.out.println(boeing.count());
	ProdusAlimentar bere = new ProdusAlimentar();
	ProdusNealimentar clor = new ProdusNealimentar();
	bere.setPrice(3.5);
	clor.setPrice(2.1);
	System.out.println("The price of beer: " + bere.calculatePrice()) ;
	System.out.println("The price of clor: " + clor.calculatePrice());
	
	Asigurare asigurare = new Asigurare();
	Asigurator omniasig = new Asigurator();
	asigurare.setColor("green");
	asigurare.setExpires("12/12/2012");
	asigurare.setNrAuto("IS 06 NBA");
	asigurare.pay();
	asigurare.pay("CASCO");
	omniasig.setColor("blue");
	System.out.println(asigurare.getExpires());
	}

}
