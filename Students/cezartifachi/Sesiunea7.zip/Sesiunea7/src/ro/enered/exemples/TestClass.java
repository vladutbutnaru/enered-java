package ro.enered.exemples;

public class TestClass {
private double pret;

public double getPret() {
	return pret;
}

public void setPret(double pret) {
	this.pret = pret;
}	

	
	
	
}
