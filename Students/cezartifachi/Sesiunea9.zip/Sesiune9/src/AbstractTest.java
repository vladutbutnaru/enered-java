
public abstract class AbstractTest {
public void run(){
	System.out.println("Running.........");
	
	
}
}
