
public class Main {

	public static void main(String[] args) {
		Test t1 = new Test();
		Test t2 = new Test();
		Test t3 = new Test();
		System.out.println(t1.numberOfInstances);
		t1.run();

	}

}

/*
1. Inheritance 
- cream o super clasa
- cream o a doua clasa ( clasa 2 extends super clasa)
- super.(metdod or variable)
- super(....); - asa se apeleaza constructorul;

2. Interfata + OVERIDING

Interfata are doar semnatura metodelor

- create interface - 
public interface COUNTABLE{
	public void count();
}
-utilizarea iunterfetei:
	public class Apple IMPLEMENTS countable

3. Overloading

public string display(){
}


**/