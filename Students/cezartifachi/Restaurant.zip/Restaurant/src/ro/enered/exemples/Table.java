package ro.enered.exemples;

import java.util.ArrayList;

public class Table {
private boolean available;
private int nrMasa;
ArrayList<User> users;
// constructor START
public Table(int nrMasa){
	setNrMasa(nrMasa); // == this.index=index
	users = new ArrayList<User>();  // instantiem
	setAvailable(true);  // la inceput sunt available toate mesele
	
	
	
}
//constructor END
// setters and getters START
public boolean isAvailable() {
	return available;
}
public void setAvailable(boolean available) {
	this.available = available;
}
public int getNrMasa() {
	return nrMasa;
}
public void setNrMasa(int index) {
	this.nrMasa = index;
}
public ArrayList<User> getUsers() {
	return users;
}
public void setUsers(ArrayList<User> users) {
	this.users = users;
}
// setters and getters END
//methods START
public void reserve(User u){
	if(isAvailable()){
		//reserve it by adding the user to the list
	users.add(u);
	//add setting the available flat to false
	setAvailable(false);
	//we show message
	System.out.println("Table succesfuly reverved");
	}else{
		System.out.println("Table is not available");
	}
}
public void leaveTable(){
	setAvailable(true);
}
public void showHistory(){
	System.out.println("The table with number: " + getNrMasa() + "had the following customers: " );
	for (int i = 0; i<users.size(); i++){
		System.out.println(users.get(i).getName());
		
	}
	System.out.println();
}
}
