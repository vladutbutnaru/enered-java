package ro.enered.exemples;

import java.util.ArrayList;
import java.util.Scanner;

public class Menu {
	// Initial methood START
public void startApp(){
	//instantiere tables 
	Table table1 = new Table(1);
	Table table2 = new Table(2);
	Table table3 = new Table(3);
	Table table4 = new Table(4);
	//instantiere Arrays
	ArrayList<Table> tables = new ArrayList<Table>();
	// add tables to array list
	tables.add(table1);
	tables.add(table2);
	tables.add(table3);
	tables.add(table4);
	//instantiere user
	User user = new User();
	
	// instantiate reader(that reads from console)
	Scanner reader = new Scanner(System.in);
	//show menu
	showMenu();
	//option will save the current selection
	int option = reader.nextInt();
	//while user doesent chose 6 (Exit)
	while (option !=6){
		switch(option){
		//display available tables
		case 1:
			for (int i= 0; i<tables.size(); i++){
				if(tables.get(i).isAvailable()){
					System.out.println(tables.get(i).getNrMasa());
				}
			}
			break;
			//reserve table
		case 2:
			//we ask what is his name
			System.out.println("What is your name?");
			//we set name of the user instance to the name given
			String name = reader.next();
			User user2 = new User();	
			user2.setName(name);
			//we ask what table he wants
			System.out.println("Witch table would you like to reserve?");
			// we save his answer in chosenTable
			int chosenTable = reader.nextInt();
			//we search for the table with the numner chosenTable in the ArrayList tables
			for (int i =0;i<tables.size();i++){
				//if the current table has the number asked for
				if(tables.get(i).getNrMasa() == chosenTable){
					//we reserve the table
					tables.get(i).reserve(user2);
					
				}
			}
			break;
		case 3:
			//we ask what table he wants
			System.out.println("Witch table would you like to leave?");
			// we save his answer in chosenTable
			chosenTable = reader.nextInt();
			//we search for the table with the numner chosenTable in the ArrayList tables
			for (int i =0;i<tables.size();i++){
				//if the current table has the number asked for
				if(tables.get(i).getNrMasa() == chosenTable){
					//we free the table
					tables.get(i).leaveTable();
					//we show message
					System.out.println("Table is now free");
				}
			}
			break;
		case 4:
			int max =0;
			Table maxTable = new Table(8);
			for (int i =0;i<tables.size();i++){
			//see what table had the most users
				if(tables.get(i).users.size() > max){
					//set the new maximum number to the new one
					max = tables.get(i).users.size();
					//save the Table instance3 with the most users
					maxTable = tables.get(i);
				}
			
			}
			//Display table numer - cu cel mai mare numar de users
			System.out.println(maxTable.getNrMasa());
			break;
		case 5:
			//for wach table, we show the history
			for (int i =0;i<tables.size();i++){
				//we call showHistory
				tables.get(i).showHistory();
			}
			break;
			
			}
		showMenu();
		option = reader.nextInt();
		}
	}
		
	
	
	

public void showMenu(){
	System.out.println("-----------------------");
	System.out.println("1. Customer - check free tables");
	System.out.println("2. Customer - reserve a table");
	System.out.println("3. Customer - leave restaurant");
	System.out.println("4. Admin - view most popular table");
	System.out.println("5. Admin - view each table history");
	System.out.println("6. Exit");
	System.out.println("-----------------------");
}
}
