package ro.cbe.servlets;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import ro.cbe.controllers.CbeAuthController;
import ro.cbe.controllers.CbeElevController;
import ro.cbe.controllers.CbeProfesorController;

/**
 * Servlet implementation class CbeAuthServlet
 */
@WebServlet("/CbeAuthServlet")
public class CbeAuthServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

    /**
     * Default constructor. 
     */
    public CbeAuthServlet() {
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		CbeAuthController auth=new CbeAuthController();
		CbeElevController elev=new CbeElevController();
		CbeProfesorController prof= new CbeProfesorController();
		if(request.getParameter("tip").equals("elev")){
			if(auth.loginElev(request.getParameter("user"), request.getParameter("pass"))){
				Cookie loginCookie = new Cookie("elev", elev.getByAuth(request.getParameter("user"), request.getParameter("pass"))+"");
				loginCookie.setMaxAge(30*60);
				response.addCookie(loginCookie);
				response.sendRedirect("elev.jsp");
			}
		}else if(request.getParameter("tip").equals("profesor")){
			if(auth.loginProfesor(request.getParameter("user"), request.getParameter("pass"))){
				Cookie loginCookie = new Cookie("profesor", prof.getByAuth(request.getParameter("user"), request.getParameter("pass"))+"");
				loginCookie.setMaxAge(30*60);
				response.addCookie(loginCookie);
				response.sendRedirect("profesor.jsp");
		}
	}

}
}
