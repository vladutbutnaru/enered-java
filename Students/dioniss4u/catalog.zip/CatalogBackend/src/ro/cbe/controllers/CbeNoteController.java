package ro.cbe.controllers;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;

import ro.cbe.entities.CbeNote;
import ro.cbe.entities.CbeProfesor;
import ro.cbe.utils.DBConnection;

public class CbeNoteController {
	DBConnection c=new DBConnection();
	Connection con=c.getConnection();		
	PreparedStatement pst;
	ResultSet rs;
	
	public ArrayList<CbeNote> getNoteByMaterie(int idelev,String materie,int sem){
		ArrayList<CbeNote> listNote = null;
		CbeNote nota = null;
		try {
			CbeProfesorController p=new CbeProfesorController();
			
			pst=con.prepareStatement("select * from note where IDELEV=? and IDPROFESOR=? and SEM=?");
			pst.setInt(1, idelev);
			pst.setInt(2, p.getByMaterie(materie).getId());
			pst.setInt(3, sem);
			rs=pst.executeQuery();
			while(rs.next()){
				nota.setId(rs.getInt("ID"));
				nota.setData(rs.getString("DATA"));
				nota.setNota(rs.getInt("NOTA"));
				listNote.add(nota);
				
			}
			return listNote;
		} catch (Exception e) {
			// TODO: handle exception
		}
		return listNote;
	}
	public double getMedieByMaterie(int idelev, String materie,int sem){
		double medie = 0;
		try {
			CbeProfesorController p=new CbeProfesorController();
			pst=con.prepareStatement("select * from note where IDELEV=? and IDPROFESOR=? and SEM=?");
			pst.setInt(1, idelev);
			pst.setInt(2, p.getByMaterie(materie).getId());
			pst.setInt(3, sem);
			rs=pst.executeQuery();
			while(rs.next()){
				if(medie!=0){
				medie+=rs.getInt("NOTA");
				medie=medie/2;
				}else{
					medie+=rs.getInt("NOTA");
				}
			}
			
			
		} catch (Exception e) {
			// TODO: handle exception
		}
		return medie;
	}
	public double getMedieGenerala(int idelev,int sem){
		double mg=0;
		ArrayList<CbeProfesor> profi = null;
		try {
			 pst=con.prepareStatement("select ID from profesor");
			 rs=pst.executeQuery();
			 while(rs.next()){
				CbeProfesor p=new CbeProfesor();
				p.setId(rs.getInt("ID"));
				profi.add(p);
			 }
			 for(CbeProfesor p:profi){
				 double mm = 0;
				 pst=con.prepareStatement("select NOTA from note where IDELEV=? and IDPROFESOR=? and SEM=?");
				 pst.setInt(1, idelev);
				 pst.setInt(2, p.getId());
				 pst.setInt(3, sem);
				 rs=pst.executeQuery();
				 while(rs.next()){
					if(mm!=0){
						mm+=rs.getInt("NOTA");
						mm=mm/2;
					}else{
						mm+=rs.getInt("NOTA");
					}
				 }
				 if(mg!=0){
					 mg+=mm;
					 mg=mg/2;
				 }else{
					 mg+=mm;
				 }
			 }
			
			
			
		} catch (Exception e) {
			// TODO: handle exception
		}
		
		
		return mg;
	}
	public void addNota(int idelev,int idprofesor,int nota,int sem,String data){
		try {
			pst=con.prepareStatement("insert into note(IDELEV,IDPROFESOR,NOTA,DATA,SEM) Values(?,?,?,?,?)");
			pst.setInt(1, idelev);
			pst.setInt(2, idprofesor);
			pst.setInt(3, nota);
			pst.setString(4, data);
			pst.setInt(5, sem);
			pst.executeUpdate();
		} catch (Exception e) {
			// TODO: handle exception
		}
	}
}
