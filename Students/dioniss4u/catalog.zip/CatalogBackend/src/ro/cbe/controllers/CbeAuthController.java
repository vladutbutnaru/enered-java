package ro.cbe.controllers;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import ro.cbe.utils.DBConnection;

public class CbeAuthController {
	DBConnection c=new DBConnection();
	Connection con=c.getConnection();		
	PreparedStatement pst;
	ResultSet rs;
	public boolean loginElev(String u, String p){
		try {
			pst= con.prepareStatement("select * elev where USER=? ");
			pst.setString(1, u);
			rs=pst.executeQuery();
			while(rs.next()){
				if(rs.getString("PASS").equals(p)){
					return true;
				}
			}
			
			
			
			
			
		} catch (Exception e) {
			// TODO: handle exception
		}
		return false;
	}
	public boolean loginProfesor(String u, String p){
		try {
			pst= con.prepareStatement("select * profesor where USER=? ");
			pst.setString(1, u);
			rs=pst.executeQuery();
			while(rs.next()){
				if(rs.getString("PASS").equals(p)){
					return true;
				}
			}
			
	
	} catch (Exception e) {
		// TODO: handle exception
	}
	return false;

	}
}
