package ro.cbe.controllers;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import ro.cbe.entities.CbeElev;
import ro.cbe.utils.DBConnection;

public class CbeElevController {
	DBConnection c=new DBConnection();
	Connection con=c.getConnection();		
	PreparedStatement pst;
	ResultSet rs;
	public int getByAuth(String u,String p){
		int id=0;
		try {
			pst=con.prepareStatement("select ID from elev where USER=? and PASS=?");
			pst.setString(1, u);
			pst.setString(2, p);
			rs=pst.executeQuery();
			while(rs.next()){
				id=rs.getInt("ID");
			}
			
		} catch (Exception e) {
			// TODO: handle exception
		}
		return id;
	}
	
	public CbeElev getById(int id){
		CbeElev e= new CbeElev();
		try {
			
			pst=con.prepareStatement("select * elev where ID=?");
			pst.setInt(1, id);
			rs=pst.executeQuery();
			while(rs.next()){
				e.setId(id);
				e.setNume(rs.getString("NUME"));
				e.setClasa(rs.getString("CLASA"));
			}
			return e;
			
		} catch (Exception ex) {
			// TODO: handle exception
		}
		return e;
	}
	public void addElev(String n, String u,String p,String c){
		try {
			pst=con.prepareStatement("insert into elev(NUME,USER,PASS,CLASA) values(?,?,?,?)");
			pst.setString(1, n);
			pst.setString(2,u);
			pst.setString(3, p);
			pst.setString(4, c);
			pst.executeUpdate();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
	public void updateElev(int id,String n, String u,String p,String c){
		try {
			pst=con.prepareStatement("update elev Name=?,USER=?,PASS=?,CLASA=? where ID=?");
			pst.setString(1, n);
			pst.setString(2,u);
			pst.setString(3, p);
			pst.setString(4, c);
			pst.setInt(5, id);
			pst.executeUpdate();
		} catch (Exception e) {
			// TODO: handle exception
		}
	}
	public void deleteElev(int id){
		try {
			pst=con.prepareStatement("delete from elev where ID=?");
			pst.setInt(1, id);
			pst.executeUpdate();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

}
