package ro.cbe.controllers;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import ro.cbe.entities.CbeAbsente;
import ro.cbe.utils.DBConnection;

public class CbeAbsenteController {
	DBConnection c=new DBConnection();
	Connection con=c.getConnection();		
	PreparedStatement pst;
	ResultSet rs;
	ArrayList<CbeAbsente> absente;
	public void addAbsenta(int idelev,String data,int idprofesor, int sem){
		String materie=null;
		try {
			pst=con.prepareStatement("select MATERIE from professor where ID=?");
			pst.setInt(1, idprofesor);
			rs=pst.executeQuery();
			while(rs.next()){
				materie=rs.getString("MATERIE");
			}
			pst=con.prepareStatement("insert into absente(DATA,IDELEV,MATERIE,SEM) values(?,?,?,?)");
			pst.setString(1, materie);
			pst.setInt(2, idelev);
			pst.setString(3, data);
			pst.setInt(4, sem);
			pst.executeUpdate();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
	public void deleteAbsenta(int idAbsenta){
		try {
			pst=con.prepareStatement("delete from absente where ID=?");
			pst.setInt(1, idAbsenta);
			pst.executeUpdate();
			
			
			
		} catch (Exception e) {
			// TODO: handle exception
		}
	}
	public ArrayList<CbeAbsente> absenteById(int idelev,String clasa,int sem){
		
		try {
		
			pst=con.prepareStatement("select * absente where IDELEV=? and CLASA=? and SEM=?");
			pst.setInt(1, idelev);
			pst.setString(2, clasa);
			pst.setInt(3, sem);
			rs=pst.executeQuery();
			while(rs.next()){
				CbeAbsente a=new CbeAbsente();
				a.setId(rs.getInt("ID"));
				a.setData(rs.getString("DATA"));
				a.setIdelev(idelev);
				a.setSem(sem);
				a.setMaterie(rs.getString("MATERIE"));
				absente.add(a);
			}
			
			return absente;
			
		} catch (Exception e) {
			// TODO: handle exception
		}
		return absente;
	}
	public ArrayList<CbeAbsente> absenteByMaterie(int idelev,int idprof,String clasa,int sem){
		try {
			String materie = null;
			pst=con.prepareStatement("select MATERIE from professor where ID=?");
			pst.setInt(1, idprof);
			rs=pst.executeQuery();
			while(rs.next()){
				materie=rs.getString("MATERIE");
			}
			pst=con.prepareStatement("select * absente where IDELEV=? and MATERIE=? and CLASA=? and SEM=?");
			pst.setInt(1, idelev);
			pst.setString(2, materie);
			pst.setString(3, clasa);
			pst.setInt(4, sem);
			rs=pst.executeQuery();
			while(rs.next()){
				CbeAbsente a=new CbeAbsente();
				a.setId(rs.getInt("ID"));
				a.setData(rs.getString("DATA"));
				a.setIdelev(idelev);
				a.setMaterie(rs.getString("MATERIE"));
				a.setSem(sem);
				absente.add(a);
			}
			
			return absente;
			
		} catch (Exception e) {
			// TODO: handle exception
		}
		return absente;
	}
	

}
