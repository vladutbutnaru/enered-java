package ro.cbe.controllers;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;


import ro.cbe.entities.CbeProfesor;
import ro.cbe.utils.DBConnection;

public class CbeProfesorController {
	DBConnection c=new DBConnection();
	Connection con=c.getConnection();		
	PreparedStatement pst;
	ResultSet rs;
	
	public int getByAuth(String u,String p){
		int id=0;
		try {
			pst=con.prepareStatement("select ID from profesor where USER=? and PASS=?");
			pst.setString(1, u);
			pst.setString(2, p);
			rs=pst.executeQuery();
			while(rs.next()){
				id=rs.getInt("ID");
			}
			
		} catch (Exception e) {
			// TODO: handle exception
		}
		return id;
	}
	public CbeProfesor getById(int id){
		CbeProfesor e= new CbeProfesor();
		try {
			
			pst=con.prepareStatement("select * profesor where ID=?");
			pst.setInt(1, id);
			rs=pst.executeQuery();
			while(rs.next()){
				e.setId(id);
				e.setNume(rs.getString("NUME"));
				e.setMaterie(rs.getString("MATERIE"));
			}
			return e;
			
		} catch (Exception ex) {
			// TODO: handle exception
		}
		return e;
	}
	public CbeProfesor getByMaterie(String materie){
		CbeProfesor e= new CbeProfesor();
		try {
			
			pst=con.prepareStatement("select * profesor where MATERIE=?");
			pst.setString(1, materie);
			rs=pst.executeQuery();
			while(rs.next()){
				e.setId(rs.getInt("ID"));
				e.setNume(rs.getString("NUME"));
				e.setMaterie(rs.getString("MATERIE"));
			}
			return e;
			
		} catch (Exception ex) {
			// TODO: handle exception
		}
		return e;
	}
	public void addProfesor(String n, String u,String p,String c){
		try {
			pst=con.prepareStatement("insert into profesor(NUME,USER,PASS,MATERIE) values(?,?,?,?)");
			pst.setString(1, n);
			pst.setString(2,u);
			pst.setString(3, p);
			pst.setString(4, c);
			pst.executeUpdate();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
	public void updateProfesor(int id,String n, String u,String p,String c){
		try {
			pst=con.prepareStatement("update profesor Name=?,USER=?,PASS=?,MATERIE=? where ID=?");
			pst.setString(1, n);
			pst.setString(2,u);
			pst.setString(3, p);
			pst.setString(4, c);
			pst.setInt(5, id);
			pst.executeUpdate();
		} catch (Exception e) {
			// TODO: handle exception
		}
	}
	public void deleteProfesor(int id){
		try {
			pst=con.prepareStatement("delete from profesor where ID=?");
			pst.setInt(1, id);
			pst.executeUpdate();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}


}
