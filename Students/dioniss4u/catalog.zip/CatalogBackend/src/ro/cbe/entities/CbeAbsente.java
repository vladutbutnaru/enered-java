package ro.cbe.entities;

public class CbeAbsente {
	private int id;
	private String data;
	private int idelev;
	private int idprofesor;
	private String materie;
	private int sem;
	
	
	public int getSem() {
		return sem;
	}
	public void setSem(int sem) {
		this.sem = sem;
	}
	public String getMaterie() {
		return materie;
	}
	public void setMaterie(String materie) {
		this.materie = materie;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getData() {
		return data;
	}
	public void setData(String data) {
		this.data = data;
	}
	public int getIdelev() {
		return idelev;
	}
	public void setIdelev(int idelev) {
		this.idelev = idelev;
	}
	public int getIdprofesor() {
		return idprofesor;
	}
	public void setIdprofesor(int idprofesor) {
		this.idprofesor = idprofesor;
	}

	

}
