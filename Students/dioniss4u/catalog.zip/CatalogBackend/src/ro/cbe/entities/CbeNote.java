package ro.cbe.entities;

public class CbeNote {
	private int id;
	private int nota;
	private int idelev;
	private int idprofesor;
	private String data;
	private int sem;
	
	public int getSem() {
		return sem;
	}
	public void setSem(int sem) {
		this.sem = sem;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public int getNota() {
		return nota;
	}
	public void setNota(int nota) {
		this.nota = nota;
	}
	public int getIdelev() {
		return idelev;
	}
	public void setIdelev(int idelev) {
		this.idelev = idelev;
	}
	public int getIdprofesor() {
		return idprofesor;
	}
	public void setIdprofesor(int idprofesor) {
		this.idprofesor = idprofesor;
	}
	public String getData() {
		return data;
	}
	public void setData(String data) {
		this.data = data;
	}
	

}
