package ro.cbe.entities;

public class CbeElev {
	private int id;
	private String nume;
	private String user;
	private String pass;
	private String clasa;
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getNume() {
		return nume;
	}
	public void setNume(String nume) {
		this.nume = nume;
	}
	public String getUser() {
		return user;
	}
	public void setUser(String user) {
		this.user = user;
	}
	public String getPass() {
		return pass;
	}
	public void setPass(String pass) {
		this.pass = pass;
	}
	public String getClasa() {
		return clasa;
	}
	public void setClasa(String clasa) {
		this.clasa = clasa;
	}
	
	

}
