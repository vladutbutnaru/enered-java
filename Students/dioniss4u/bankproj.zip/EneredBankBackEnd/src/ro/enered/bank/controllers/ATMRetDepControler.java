package ro.enered.bank.controllers;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.mysql.jdbc.PreparedStatement;

import ro.enered.bank.utils.DBConnection;

public class ATMRetDepControler {
		DBConnection con=new DBConnection();
		Connection conn =  con.getConnection();
		PreparedStatement pst=null;
		ResultSet rs = null;
		double binitial;
		double bfinal;
		
	public String Retragere(String card, double suma){
		try{
		pst=(PreparedStatement) conn.prepareStatement("select Balanta from Accounts where CardNumber=?");
		pst.setString(1, card);
		rs=pst.executeQuery();
	
		
		while(rs.next()){
			binitial=rs.getDouble("Balanta");
			
		}
		
		if(binitial>=suma){
			bfinal=binitial-suma;
			
			try {
				pst=(PreparedStatement) conn.prepareStatement("update Accounts set Balanta='"+bfinal+"' where CardNumber='"+card+"'");
				pst.executeUpdate();
				return "OK";
				
			}
			catch (SQLException ex){
			   
			    System.out.println("SQLException: " + ex.getMessage());
			    System.out.println("SQLState: " + ex.getSQLState());
			    System.out.println("VendorError: " + ex.getErrorCode());
			   
			}
		}
		
		
		}
		catch (SQLException ex){
		    // handle any errors
		    System.out.println("SQLException: " + ex.getMessage());
		    System.out.println("SQLState: " + ex.getSQLState());
		    System.out.println("VendorError: " + ex.getErrorCode());
		   
		}
		return "NOK-Fonduri insuficiente";
		
	}
	public String Depunere(String card, double suma){
		try{
			pst=(PreparedStatement) conn.prepareStatement("select Balanta from Accounts where CardNumber=?");
			pst.setString(1, card);
			rs=pst.executeQuery();
			while(rs.next()){
				binitial=rs.getDouble("Balanta");
			}
			
				bfinal=binitial+suma;
				try {
					pst=(PreparedStatement) conn.prepareStatement("update Accounts set Balanta='"+bfinal+"' where CardNumber='"+card+"'");
					pst.executeUpdate();
					return "OK";
					
				}
				catch (SQLException ex){
				   
				    System.out.println("SQLException: " + ex.getMessage());
				    System.out.println("SQLState: " + ex.getSQLState());
				    System.out.println("VendorError: " + ex.getErrorCode());
				   
				}
			
			
			
			}
			catch (SQLException ex){
			    // handle any errors
			    System.out.println("SQLException: " + ex.getMessage());
			    System.out.println("SQLState: " + ex.getSQLState());
			    System.out.println("VendorError: " + ex.getErrorCode());
			   
			}
			return "NOK";
	}

}
