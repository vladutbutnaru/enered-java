package ro.enered.bank.controllers;

import java.sql.Connection;
import java.sql.ResultSet;
import java.util.Calendar;

import com.mysql.jdbc.PreparedStatement;

import ro.enered.bank.utils.DBConnection;

public class ATMPlataControler {
	DBConnection con=new DBConnection();
	Connection conn =  con.getConnection();
	PreparedStatement pst=null;
	ResultSet rs = null;
	public String Plata(int idBeneficiar, String card, double suma,String valuta,int idatm,String detalii){
		double balanta=0.0;
		int idcard=0;
		java.sql.Date date = new java.sql.Date(Calendar.getInstance().getTime().getTime());
		
		try {
			pst=(PreparedStatement) conn.prepareStatement("select Balanta,ID from Accounts where CardNumber=?");
			pst.setString(1,card);
			rs=pst.executeQuery();
			while(rs.next()){
				balanta=rs.getDouble("Balanta");
				idcard=rs.getInt("ID");
			}
			if(suma<=balanta){
				pst=(PreparedStatement) conn.prepareStatement("update Accounts set Balanta=? where CardNumber=?");
				pst.setDouble(1, balanta-suma);
				pst.setString(2, card);
				pst.executeUpdate();
				pst=(PreparedStatement) conn.prepareStatement("insert into Transactions ID_Platitor,ID_Beneficiar,Data,Suma,Valuta,Status,ID_ATM,Detalii values=(?,?,?,?,?,?,?,?)");
				pst.setInt(1, idcard);
				pst.setInt(2, idBeneficiar);
				pst.setDate(3, date);
				pst.setDouble(4, suma);
				pst.setString(5, valuta);
				pst.setString(6, "Pending");
				pst.setInt(7, idatm);
				pst.setString(8, detalii);
				pst.executeUpdate();
				return "OK";
				
				
			}
			
			
			
		} catch (Exception e) {
			
		}
		
		
		
		
		
		
		
		return "NOK";
	}
	

}
