package ro.enered.bank.servlets;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import ro.enered.bank.controllers.ATMPlataControler;

/**
 * Servlet implementation class ATMPlataServlet
 */
@WebServlet("/ATMPlataServlet")
public class ATMPlataServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public ATMPlataServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		ATMPlataControler pc=new ATMPlataControler();
		response.getWriter().append(pc.Plata(Integer.parseInt(request.getParameter("idBeneficiar")), request.getParameter("card"), Double.parseDouble(request.getParameter("suma")), request.getParameter("valuta"), Integer.parseInt(request.getParameter("idatm")), request.getParameter("detalii")));
	}

}
