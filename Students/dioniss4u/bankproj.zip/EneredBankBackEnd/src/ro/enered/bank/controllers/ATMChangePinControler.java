package ro.enered.bank.controllers;

import java.sql.Connection;
import java.sql.ResultSet;

import com.mysql.jdbc.PreparedStatement;

import ro.enered.bank.utils.DBConnection;

public class ATMChangePinControler {
	public String ChPin(String card,String pinVechi,String pinNou){
		DBConnection con=new DBConnection();
		Connection conn =  con.getConnection();
		PreparedStatement pst=null;
		ResultSet rs = null;	
		String oldPin=null;
		try {
			pst=(PreparedStatement) conn.prepareStatement("select PIN from Accounts where CardNumber=?");
			pst.setString(1, card);
			rs=pst.executeQuery();
			while(rs.next()){
				oldPin=rs.getString("PIN");
			}
			if(oldPin.equals(pinVechi)){
			if(pinVechi.equals(pinNou)){
				return "PIN-ul vechi si cel nou coincid";
			}else{
				pst=(PreparedStatement) conn.prepareStatement("update Accounts set PIN=? where CardNumber=?");
				pst.setString(1, pinNou);
				pst.setString(2, card);
				pst.executeUpdate();
				return "OK";
			}
			}
			
			
		} catch (Exception e) {
			
		}
		
		
		
		
		return "Incorect old PIN";
	}
}
