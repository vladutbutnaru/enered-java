
public class Main {
	public static void main(String [] argd){
		
		Student cristi=new Student("Cristi",23);
		Student ion=new Student();
		ion.setNume("Ion");
		ion.setVarsta(62);
		System.out.println(cristi.returneaza());
		System.out.println(ion.returneaza());
		Colectiv c1=new Colectiv();
		c1.setStudent1(cristi);
		c1.setStudent2(ion);
		c1.rcolectiv();
	}
		
		
		
		
		
		
			
		
		
		
	
	
	}


