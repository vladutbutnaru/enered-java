
public class Controller {
public void callMethod(){
	//Vreu sa apelez metoda walkAnimals din Owner cu parametrul 7
	
	Owner gigel=new Owner();
	
	gigel.setDog(new Dog());
	gigel.setCat(new Cat("Tom2", "Rosie",4));
	
	gigel.walkAnimals(8);
	
}
}
