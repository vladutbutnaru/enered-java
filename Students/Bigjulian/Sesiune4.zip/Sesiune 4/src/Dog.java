
public class Dog {
String name,color;	
int age;
public Dog(){
	
	
}

public String getColor() {
	return color;
}


public void setColor(String color) {
	this.color = color;
}


public int getAge() {
	return age;
}


public void setAge(int age) {
	this.age = age;
}


public void talk (){
	System.out.println("Blaf");
}

public void walk(int km){
	System.out.println("The dog walked " + km + " km");
}

public String suffix(String sufix){
	return name+sufix;
	
}
public void setName(String name){
	this.name=name;
	
}
}
