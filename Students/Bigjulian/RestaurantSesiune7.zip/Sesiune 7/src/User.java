
public class User {
private String name;
public String getName() {
	return name;
}
public void setName(String name) {
	this.name = name;
}
public boolean isAdmin() {
	return admin;
}
public void setAdmin(boolean admin) {
	this.admin = admin;
}
private boolean admin;
}
