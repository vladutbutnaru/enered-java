import java.util.ArrayList;

public class Table {
private boolean available;
private int nrMasa;
ArrayList<User> users;
//constructor START
public Table(int nrMasa){
	setnrMasa(nrMasa); // == this.nrMasa=nrMasa
	users = new ArrayList<User>(); // instantiem
	setAvailable(true); // la inceput sunt available
}
//constructorul se termina

public boolean isAvailable() {
	return available;
}
public void setAvailable(boolean available) {
	this.available = available;
}
public int getnrMasa() {
	return nrMasa;
}
public void setnrMasa(int nrMasa) {
	this.nrMasa = nrMasa;
}
public ArrayList<User> getUsers() {
	return users;
}
public void setUsers(ArrayList<User> users) {
	this.users = users;
}
//getters and setters END
//methods START
public void reserve(User u){
	//check if table is available
	if(isAvailable()){
		//reserve it by adding the user to the list
	users.add(u);
	//and setting the available flag to false
	setAvailable(false);
	//we show message
	System.out.println("The table was reserved successufully");
	}
	else{
		//we show message
		System.out.println("The table is already reserved");
	}
}

public void leaveTable(){
	setAvailable(true);
	
}

public void showHistory(){
	System.out.println("The table with number: " + getnrMasa() + "had the following customers " );
	for (int i=0; i<users.size(); i++){
		System.out.println(users.get(i).getName());
		
	}
	System.out.println();
}
}
