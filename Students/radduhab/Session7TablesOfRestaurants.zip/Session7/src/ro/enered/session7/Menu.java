package ro.enered.session7;

import java.util.ArrayList;
import java.util.Scanner;

public class Menu {
	public void startApp() {
		Table table1 = new Table(1);
		Table table2 = new Table(2);
		Table table3 = new Table(3);
		Table table4 = new Table(4);
		ArrayList<Table> tables = new ArrayList<Table>();
		tables.add(table1);
		tables.add(table2);
		tables.add(table3);
		tables.add(table4);
		User user = new User();
		Scanner reader = new Scanner(System.in);
		showMenu();
		int option = reader.nextInt();
		while (option != 6) {
			switch (option) {
			case 1:
				for (int i = 0; i < tables.size(); i++) {
					if (tables.get(i).isAvailable()) {
						System.out.println(tables.get(i).getnrMasa());
					}
				}
				break;
			case 2:
				System.out.println("What is your name?");
				String name = reader.next();
				User user2 = new User();
				user2.setName(name);
				System.out.println("Which table would you like?");
				int chosenTable = reader.nextInt();
				for (int i = 0; i < tables.size(); i++) {
					if (tables.get(i).getnrMasa() == chosenTable) {

						tables.get(i).reserve(user2);

					}
				}
				break;
			case 3:
				System.out.println("Which table would you like to leave");
				chosenTable = reader.nextInt();
				for (int i = 0; i < tables.size(); i++) {
					if (tables.get(i).getnrMasa() == chosenTable) {

						tables.get(i).leaveTable();
						System.out.println("Table is now free");
					}
				}
				break;
			case 4:
				int max = 0;
				Table maxTable = new Table(8);
				for (int i = 0; i < tables.size(); i++) {
					if (tables.get(i).users.size() > max) {
						max = tables.get(i).users.size();
						maxTable = tables.get(i);
					}
				}
				System.out.println(maxTable.getnrMasa());
				break;
			case 5:
				for (int i = 0; i < tables.size(); i++) {
					tables.get(i).showHistory();
				}
				break;
			}

			showMenu();
			option = reader.nextInt();
		}

	}

	public void showMenu() {
		System.out.println("-------------------------------");
		System.out.println("1. Customer - check free tables");
		System.out.println("2. Customer - reserve a table");
		System.out.println("3. Customer - leave restaurant");
		System.out.println("4. Admin - view most popular table");
		System.out.println("5. view each table history");
		System.out.println("6. Exit");
		System.out.println("-------------------------------");

	}

}
