package ro.enered.session7;

import java.util.ArrayList;

public class Table {
	private boolean available;
	private int nrMasa;
	ArrayList<User> users;
	public Table(int nrMasa){
		setnrMasa(nrMasa); //sau this.nrMasa=nrMasa;
		users = new ArrayList<User>();//instantiem
		setAvailable(true);//la inceput sunt available
	}
	public boolean isAvailable() {
		return available;
	}
	public void setAvailable(boolean available) {
		this.available = available;
	}
	public int getnrMasa() {
		return nrMasa;
	}
	public void setnrMasa(int nrMasa) {
		this.nrMasa = nrMasa;
	}
	public ArrayList<User> getUsers() {
		return users;
	}
	public void setUsers(ArrayList<User> users) {
		this.users = users;
	}
	//metoda reserve Start
	public void reserve(User u){
		if(isAvailable()){
		users.add(u);
		setAvailable(false);
		System.out.println("The table was reserved successfully");
		}
		else {
			System.out.println("The table is already reserved");
		}
		
	}
	public void leaveTable(){
		setAvailable(true);
		
	}
	public void showHistory(){
		System.out.println("The table with nrMasa: "+ getnrMasa()+ "had the following customers" );
		for(int i=0; i<users.size();i++){
			System.out.println(users.get(i).getName());
		}
		System.out.println();
	}
}
