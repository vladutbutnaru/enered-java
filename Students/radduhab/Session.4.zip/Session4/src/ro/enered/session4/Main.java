package ro.enered.session4;

public class Main {
	public static void main(String[] args) {
		Student s1 = new Student("Radu", 24);
		Student s2 = new Student();
		s2.setnume("Ion");
		s2.setVarsta(24);
		System.out.println(s1.returneaza());
		System.out.println(s2.returneaza());
		Colectiv c1 = new Colectiv();
		c1.setStudent1(s1);
		c1.setStudent2(s2);
		c1.returneazacolectiv();

	}
}
