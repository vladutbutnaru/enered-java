package ro.enered.session4;

public class Student {
	String nume;
	int varsta;

	public Student() {

	}

	public String getnume() {
		return nume;
	}

	public void setnume(String nume) {
		this.nume = nume;
	}

	public int getVarsta() {
		return varsta;
	}

	public void setVarsta(int varsta) {
		this.varsta = varsta;
	}

	public Student(String nume, int varsta) {
		this.nume = nume;
		this.varsta = varsta;

	}

	public String returneaza() {
		return "Ma numesc" + nume + " si am " + varsta + " ani.";
	}
}
