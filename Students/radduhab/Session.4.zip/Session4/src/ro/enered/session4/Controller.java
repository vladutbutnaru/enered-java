package ro.enered.session4;

public class Controller {
	public void callMethod(){
		//apelam metoda walkAnimals din Owner din parametrul 7
		Owner o= new Owner();
		o.setDog(new Dog());
		o.setCat(new Cat("Tom","Mov",6));
		o.walkAnimals(8);
	}

}
