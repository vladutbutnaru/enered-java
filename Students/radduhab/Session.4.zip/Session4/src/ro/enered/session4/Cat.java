package ro.enered.session4;

public class Cat {
	String name, color;

	int age;

	// facem constructorii
	public Cat(String nume, String color, int age) {
		setName(name);
		this.color = color;
		this.age = age;
	}

	public Cat() {
	}

	public void talk() {
		System.out.println("Meow");
	}

	public void walk(int km) {
		System.out.println("The cat walked " + km + " km");
	}

	public String suffix(String sufix) {
		return name + sufix;
	}

	public void setName(String name) {
		this.name = name;
	}

	public void setColor(String color) {
		this.color = color;
	}

	public void setAge(int age) {
		this.age = age;
	}

	public String getName() {
		return name;
	}

	public String getColor() {
		return color;
	}

	public int getAge() {
		return age;
	}

}
