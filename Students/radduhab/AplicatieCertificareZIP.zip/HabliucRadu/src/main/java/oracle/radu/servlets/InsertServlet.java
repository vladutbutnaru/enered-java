package oracle.radu.servlets;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import oracle.radu.entities.Properties;
import oracle.radu.controllers.OwnerController;

public class InsertServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	public InsertServlet() {
		super();
	}

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		String name = request.getParameter("name");
		int price = Integer.parseInt(request.getParameter("price"));
		int owner = Integer.parseInt(request.getParameter("owner"));
		OwnerController ownerController = new OwnerController();
		Properties properties = new Properties();
		properties.setName(name);
		properties.setPrice(price);
		properties.setOwner(owner);

		try {
			ownerController.addProperties(properties);
			;
		} catch (Exception e) {
		}
		response.sendRedirect("owner.jsp");
	}

}
