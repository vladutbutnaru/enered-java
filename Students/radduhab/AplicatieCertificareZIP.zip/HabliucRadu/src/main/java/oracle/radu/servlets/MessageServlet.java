package oracle.radu.servlets;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import oracle.radu.controllers.MessageController;
import oracle.radu.entities.Message;

/**
 * Servlet implementation class MessageServlet
 */
public class MessageServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	public MessageServlet() {
		super();

	}

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		String message = request.getParameter("message");
		int sender = Integer.parseInt(request.getCookies()[1].getValue());
		MessageController messageController = new MessageController();
		Message mess = new Message();
		mess.setMessage(message);
		mess.setSender(sender);
		try {
			messageController.addMessage(mess);
		} catch (Exception e) {

			e.printStackTrace();
		}
		response.sendRedirect("home.jsp");
	}

}
