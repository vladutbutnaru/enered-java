package oracle.radu.controllers;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;

import oracle.radu.entities.Message;
import oracle.radu.entities.Properties;
import oracle.radu.utils.DBConnection;

public class MessageController {
	Connection c = DBConnection.getConnection();
	ResultSet rs;

	public void addMessage(Message m) throws Exception {
		PreparedStatement ps = c
				.prepareStatement("" + "INSERT INTO Messages(message,sender,receiver) " + "VALUES(?,?,?) " + "");
		ps.setString(1, m.getMessage());
		ps.setInt(2, m.getSender());
		ps.setInt(3, m.getReceiver());
		ps.executeUpdate();
	}

	public ArrayList<Message> getMessage() throws Exception {
		PreparedStatement ps = c.prepareStatement("" + "SELECT * FROM Messages");
		ArrayList<Message> messages = new ArrayList<Message>();
		rs = ps.executeQuery();
		while (rs.next()) {
			Message mess = new Message();
			mess.setId(rs.getInt(1));
			mess.setMessage(rs.getString(2));
			mess.setSender(rs.getInt(3));
			mess.setReceiver(rs.getInt(4));
			messages.add(mess);
		}
		return messages;
	}
}
