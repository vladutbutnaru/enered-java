package oracle.radu.entities;

public class Message {

	private int id;
	private String message;
	private int sender;
	private int receiver;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

	public int getSender() {
		return sender;
	}

	public void setSender(int sender) {
		this.sender = sender;
	}

	public int getReceiver() {
		return receiver;
	}

	public void setReceiver(int receiver) {
		this.receiver = receiver;
	}

	@Override
	public String toString() {
		return "Message [id=" + id + ", message=" + message + ", sender=" + sender + ", receiver=" + receiver + "]";
	}

}
