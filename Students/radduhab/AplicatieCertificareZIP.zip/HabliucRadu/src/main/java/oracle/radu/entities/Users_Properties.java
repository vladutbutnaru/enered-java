package oracle.radu.entities;

import java.sql.Timestamp;

public class Users_Properties {

	private int id;
	private int property;
	private int user;
	private Timestamp date1;
	private Timestamp date2;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public int getProperty() {
		return property;
	}

	public void setProperty(int property) {
		this.property = property;
	}

	public int getUser() {
		return user;
	}

	public void setUser(int user) {
		this.user = user;
	}

	public Timestamp getDate1() {
		return date1;
	}

	public void setDate1(Timestamp date1) {
		this.date1 = date1;
	}

	public Timestamp getDate2() {
		return date2;
	}

	public void setDate2(Timestamp date2) {
		this.date2 = date2;
	}

	@Override
	public String toString() {
		return "Users_Properties [id=" + id + ", property=" + property + ", user=" + user + ", date1=" + date1
				+ ", date2=" + date2 + "]";
	}

}
