package oracle.radu.utils;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

import oracle.radu.utils.Conf;

public class DBConnection {

	private static Connection conn = null;

	public static Connection getConnection() {
		try {
			Class.forName("com.mysql.jdbc.Driver");
		} catch (ClassNotFoundException e) {
			e.printStackTrace();

		}
		try {

			if (conn == null) {

				conn = DriverManager.getConnection("jdbc:mysql://" + Conf.DATABASE_URL + ":" + Conf.DATABASE_PORT + "/"
						+ Conf.DATABASE_NAME + "?" + "user=" + Conf.DATABASE_USER + "&password="
						+ Conf.DATABASE_PASSWORD + "&autoReconnect=true");

			}
			if (conn.isClosed()) {

				conn = DriverManager.getConnection("jdbc:mysql://" + Conf.DATABASE_URL + ":" + Conf.DATABASE_PORT + "/"
						+ Conf.DATABASE_NAME + "?" + "user=" + Conf.DATABASE_USER + "&password="
						+ Conf.DATABASE_PASSWORD + "&autoReconnect=true");
			}

		} catch (SQLException ex) {
			// handle any errors
			System.out.println("SQLException: " + ex.getMessage());
			System.out.println("SQLState: " + ex.getSQLState());
			System.out.println("VendorError: " + ex.getErrorCode());

		}
		return conn;
	}
}
