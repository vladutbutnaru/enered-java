package oracle.radu.utils;

public class Conf {
	public static final String DATABASE_URL = "baniimei.online";
	public static final int DATABASE_PORT = 3306;
	public static final String DATABASE_NAME = "ORACERTEEVLDBT";
	public static final String DATABASE_USER = "root";
	public static final String DATABASE_PASSWORD = "BaniiMeiDev1!";
}
