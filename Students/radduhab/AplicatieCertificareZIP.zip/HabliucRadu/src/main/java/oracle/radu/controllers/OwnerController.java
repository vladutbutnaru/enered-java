package oracle.radu.controllers;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import oracle.radu.entities.Properties;
import oracle.radu.utils.DBConnection;

public class OwnerController {
	Connection c = DBConnection.getConnection();
	ResultSet rs;

	public ArrayList<Properties> getProperties() throws Exception {
		PreparedStatement ps = c.prepareStatement("" + "SELECT * FROM Properties");
		ArrayList<Properties> properties = new ArrayList<Properties>();
		rs = ps.executeQuery();
		while (rs.next()) {
			Properties prop = new Properties();
			prop.setId(rs.getInt(1));
			prop.setName(rs.getString(2));
			prop.setPrice(rs.getInt(3));
			prop.setOwner(rs.getInt(4));
			properties.add(prop);
		}
		return properties;
	}

	public void addProperties(Properties p) throws Exception {
		PreparedStatement ps = c
				.prepareStatement("" + "INSERT INTO Properties(name,price,owner) " + "VALUES(?,?,?) " + "");
		ps.setString(1, p.getName());
		ps.setInt(2, p.getPrice());
		ps.setInt(3, p.getOwner());
		ps.executeUpdate();
	}

	public void deleteProperties(int id) throws Exception {
		PreparedStatement ps = c.prepareStatement("" + "DELETE FROM Properties WHERE ID = ?");
		ps.setInt(1, id);
		ps.executeUpdate();

	}

	public void updateProperties(Properties p) {
		PreparedStatement ps;
		try {
			ps = c.prepareStatement("" + "UPDATE Properties  SET name=? , price=? , owner= ? WHERE ID = ?");
			ps.setString(1, p.getName());
			ps.setInt(2, p.getPrice());
			ps.setInt(3, p.getOwner());
			ps.executeUpdate();
		} catch (SQLException e1) {
			e1.printStackTrace();
		}

	}

}
