function modify(propertiesID) {
	var id = document.getElementById("id" + propertiesID).innerHTML;
	var name = document.getElementById("name" + propertiesID).innerHTML;
	var price = document.getElementById("price" + propertiesID).innerHTML;
	var owner = document.getElementById("owner" + propertiesID).innerHTML;

	document.getElementById("editName").value = name;
	document.getElementById("editPrice").value = price;
	document.getElementById("editOwner").value = owner;

	document.getElementById("editId").value = id;
}
