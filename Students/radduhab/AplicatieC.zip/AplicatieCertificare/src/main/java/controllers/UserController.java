package controllers;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;

import Entities.User;
import utils.DBConnection;

public class UserController {
	DBConnection con = new DBConnection();
	Connection conn = con.getConnection();

	public void signUp(String username, String password) {
		String query = "insert into Authentication (username, password) values ('" + username + "','" + password
				+ "');";
		try {
			Statement s = conn.createStatement();
			s.executeUpdate(query);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	public User getById(int id) {
		String query = "select * from Authentication WHERE ID = " + id;
		User u = new User();
		try {
			Statement s = conn.createStatement();
			ResultSet rs = s.executeQuery(query);

			while (rs.next()) {
				u = new User();
				u.setID(rs.getInt(1));
				u.setUsername(rs.getString(2));
				u.setPassword(rs.getString(3));

				return u;
			}

		} catch (SQLException ex) {
			Logger.getLogger(UserController.class.getName()).log(Level.SEVERE, null, ex);
		}
		return u;
	}

	public ArrayList<User> getAll() {

		ArrayList<User> userList = new ArrayList<User>();
		String query = "select * from Authentication";
		try {
			Statement s = conn.createStatement();
			ResultSet rs = s.executeQuery(query);

			while (rs.next()) {
				User u = new User();
				u.setID(rs.getInt(1));
				u.setUsername(rs.getString(2));
				u.setPassword(rs.getString(3));
				userList.add(u);
			}

		} catch (SQLException ex) {
			Logger.getLogger(UserController.class.getName()).log(Level.SEVERE, null, ex);
		}
		return userList;
	}

}
