package controllers;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;

import Entities.Products;
import utils.DBConnection;

public class ProductController {
	DBConnection con = new DBConnection();
	Connection conn = con.getConnection();

	public ArrayList<Products> getAll() {

		ArrayList<Products> productsList = new ArrayList<Products>();
		String query = "select * from Products";
		try {
			Statement s = conn.createStatement();
			ResultSet rs = s.executeQuery(query);

			while (rs.next()) {
				Products p = new Products();
				p.setID(rs.getInt(1));
				p.setName(rs.getString(2));
				p.setDescription(rs.getString(3));
				p.setPrice(rs.getDouble(4));
				p.setQuantity(rs.getInt(5));
				productsList.add(p);
			}

		} catch (SQLException ex) {
			Logger.getLogger(UserController.class.getName()).log(Level.SEVERE, null, ex);
		}
		return productsList;
	}

}
