package oracle.radu.servlets;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import oracle.radu.entities.Article;
import oracle.radu.controllers.ArticleController;

public class InsertServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	public InsertServlet() {
		super();
	}

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		String title = request.getParameter("title");
		String content = request.getParameter("content");
		ArticleController ac = new ArticleController();
		Article a = new Article();
		a.setTitle(title);
		a.setContent(content);
		try {
			ac.addArticle(a);
		} catch (Exception e) {
		}
		response.sendRedirect("home.jsp");
	}

}
