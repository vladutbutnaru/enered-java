package oracle.radu.controllers;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import oracle.radu.entities.Article;
import oracle.radu.utils.DBConnection;

public class ArticleController {

	Connection connection = DBConnection.getConnection();
	ResultSet resultSet;

	public ArrayList<Article> getArticles() throws Exception {
		PreparedStatement preparedStatement = connection.prepareStatement("" + "SELECT * FROM Articles");
		ArrayList<Article> articles = new ArrayList<Article>();
		resultSet = preparedStatement.executeQuery();
		while (resultSet.next()) {
			Article article = new Article();
			article.setId(resultSet.getInt(1));
			article.setTitle(resultSet.getString(2));
			article.setContent(resultSet.getString(3));
			article.setPublisherID(resultSet.getInt(4));
			articles.add(article);
		}
		return articles;
	}

	public void addArticle(Article a) throws Exception {
		PreparedStatement preparedStatement = connection
				.prepareStatement("" + "INSERT INTO Articles(Title,Content,PublisherID) " + "VALUES(?,?,?) " + "");
		preparedStatement.setString(1, a.getTitle());
		preparedStatement.setString(2, a.getContent());
		preparedStatement.setInt(3, a.getPublisherID());
		preparedStatement.executeUpdate();
	}

	public void deleteArticle(int id) throws Exception {
		PreparedStatement preparedStatement = connection.prepareStatement("" + "DELETE FROM Articles WHERE ID = ?");
		preparedStatement.setInt(1, id);
		preparedStatement.executeUpdate();

	}

	public void updateArticle(Article a) {
		PreparedStatement preparedStatement;
		try {
			preparedStatement = connection
					.prepareStatement("" + "UPDATE Articles  SET Title=? , Content=? WHERE ID = ?");
			preparedStatement.setString(1, a.getTitle());
			preparedStatement.setString(2, a.getContent());
			preparedStatement.setInt(3, a.getId());
			preparedStatement.executeUpdate();
		} catch (SQLException e1) {
			e1.printStackTrace();
		}

	}
}
