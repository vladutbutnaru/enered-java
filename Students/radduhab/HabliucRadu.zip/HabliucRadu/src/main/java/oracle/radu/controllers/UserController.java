package oracle.radu.controllers;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import oracle.radu.utils.DBConnection;

public class UserController {

	private Connection c = DBConnection.getConnection();
	ResultSet rs;

	public int login(String email, String password) {

		try {
			PreparedStatement ps = c.prepareStatement("" + "SELECT * FROM Login WHERE Email = ? AND Password = ?" + "");
			ps.setString(1, email);
			ps.setString(2, password);
			rs = ps.executeQuery();
			if (rs.next()) {
				return rs.getInt("ID");

			}
		} catch (Exception e) {
		}
		return -1;

	}

	public void register(String email, String password) {
		try {
			PreparedStatement ps = c.prepareStatement("" + "INSERT INTO Login(Email,Password) VALUES(?,?)" + "");
			ps.setString(1, email);
			ps.setString(2, password);
			ps.executeUpdate();
		} catch (Exception e) {
		}
	}
}
