package oracle.radu.controllers;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import oracle.radu.utils.DBConnection;

public class UserController {

	private Connection connection = DBConnection.getConnection();
	ResultSet resultSet;

	public int login(String email, String password) {

		try {
			PreparedStatement preparedStatement = connection
					.prepareStatement("" + "SELECT * FROM Login WHERE Email = ? AND Password = ?" + "");
			preparedStatement.setString(1, email);
			preparedStatement.setString(2, password);
			resultSet = preparedStatement.executeQuery();
			if (resultSet.next()) {
				return resultSet.getInt("ID");

			}
		} catch (Exception e) {
		}
		return -1;

	}

	public void register(String email, String password) {
		try {
			PreparedStatement preparedStatement = connection
					.prepareStatement("" + "INSERT INTO Login(Email,Password) VALUES(?,?)" + "");
			preparedStatement.setString(1, email);
			preparedStatement.setString(2, password);
			preparedStatement.executeUpdate();
		} catch (Exception e) {
		}
	}
}
