package ro.raddu.utils;

public class Conf {
	public static final String DATABASE_URL = "46.101.150.186";
	public static final int DATABASE_PORT = 3306;
	public static final String DATABASE_NAME = "EmployeeDB";
	public static final String DATABASE_USER = "root";
	public static final String DATABASE_PASSWORD = "BaniiMeiDev1!";
}
