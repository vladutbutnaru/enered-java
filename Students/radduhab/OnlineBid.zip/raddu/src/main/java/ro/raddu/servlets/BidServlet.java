package ro.raddu.servlets;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import ro.raddu.controllers.BidController;
import ro.raddu.entities.Bid;

/**
 * Servlet implementation class BidServlet
 */
public class BidServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public BidServlet() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		int id = Integer.parseInt(request.getParameter("id"));
		response.sendRedirect("NewBid.jsp?id=" + id);
		// am trimis id care l am primit din homepage la newbid.jsp

	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		int id = Integer.parseInt(request.getParameter("id"));
		String email = request.getParameter("email");
		int price = Integer.parseInt(request.getParameter("price"));
		Bid b = new Bid();
		b.setEmail(email);
		b.setProductID(id);
		b.setValue(price);
		BidController bc = new BidController();
		bc.addBid(b);
		response.sendRedirect("main.jsp");
	}

}
