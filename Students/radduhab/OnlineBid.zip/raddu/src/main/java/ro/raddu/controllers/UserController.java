package ro.raddu.controllers;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import ro.raddu.entities.User;
import ro.raddu.utils.DBConnection;

public class UserController {
	Connection c = DBConnection.getConnection();

	public int login(User u) {
		try {
			PreparedStatement ps = c.prepareStatement("SELECT * FROM Users WHERE Email=? AND Password=?");
			ps.setString(1, u.getEmail());
			ps.setString(2, u.getPassword());
			ResultSet rs = ps.executeQuery();
			if (rs.next()) {
				return rs.getInt(1);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return -1;
	}

}
