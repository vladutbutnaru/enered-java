package ro.raddu.controllers;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import ro.raddu.entities.Bid;
import ro.raddu.utils.DBConnection;

public class BidController {
	Connection c = DBConnection.getConnection();

	public void addBid(Bid b) {
		try {
			PreparedStatement ps = c.prepareStatement("INSERT INTO Bids (Email,Value,ProductID) VALUES (?,?,?)");
			ps.setString(1, b.getEmail());
			ps.setInt(2, b.getValue());
			ps.setInt(3, b.getProductID());
			ps.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

}
