function getQuantity(productID) {
	var quantityID = "quantity" + productID;
	var quantity = document.getElementById(quantityID).value;

	var userID = document.getElementById("userID").value;
	$.get("BuyServlet", {
		quantity : quantity,
		id : productID,
		userID : userID
	}, function(data) {
		alert("Product has been added to cart");

	}

	);
	location.href = "home.jsp";
}