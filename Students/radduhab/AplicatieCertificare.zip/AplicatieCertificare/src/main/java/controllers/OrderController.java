package controllers;

import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Statement;

import Entities.Orders;
import utils.DBConnection;

public class OrderController {

	DBConnection con = new DBConnection();
	Connection conn = con.getConnection();

	public void addOrder(Orders o) {
		String query = "insert into Orders (UserID, ProductID,Quantity) values ('" + o.getUserID() + "','"
				+ o.getProductID() + "','" + o.getQuantity() + "');";

		String query2 = "UPDATE Products SET Quantity = Quantity - " + o.getQuantity() + " WHERE ID = "
				+ o.getProductID();
		try {
			Statement s = conn.createStatement();
			s.executeUpdate(query);
			s.executeUpdate(query2);
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

}
