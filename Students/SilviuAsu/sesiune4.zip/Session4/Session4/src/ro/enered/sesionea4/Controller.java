package ro.enered.sesionea4;

public class Controller {
	public void callMethod(){
		//Vreau sa apelez metoda walkAnimals din Owner cu parametrul 7
		Owner o=new Owner();
		
		o.setDog(new Dog());
		o.setCat(new Cat("Asu","Black",13));
		
		o.walkAnimals(9);
	}
}
