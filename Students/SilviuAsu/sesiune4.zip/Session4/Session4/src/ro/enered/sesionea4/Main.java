package ro.enered.sesionea4;

public class Main {

	public static void main(String[] args) {
		
		student silviu = new student("Silviu ", 29);
		student asu = new student();
		asu.setNume("Asu ");
		asu.setVarsta(29);
		System.out.println(silviu.manumesc());
		System.out.println(asu.manumesc());
		colectiv c1 = new colectiv();
		c1.setStuden1(silviu);
		c1.setStuden2(silviu);
		c1.rcolectiv();
//		Cat pisica = new Cat("Asu","Black",13);
//		Owner Asu = new Owner();
//		Dog dog = new Dog();
//		Controller c= new Controller();		
//		int kilometers = 121;
//		
//		//APELURI DE FUNTII
//		Asu.setCat(pisica);
//		Asu.setDog(dog);
//		
//		
//		pisica.talk();
//		pisica.walk(kilometers);
//		c.callMethod();
//		Asu.walkAnimals(6);
//		
//		//AFISARE
//		System.out.println(pisica.sufix("ului"));
//		System.out.println();

		
		


	}

}
