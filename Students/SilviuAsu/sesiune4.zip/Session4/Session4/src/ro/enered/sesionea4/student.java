package ro.enered.sesionea4;

public class student {
String nume;
int varsta;

public student() {
	
}
public String getNume() {
	return nume;
}
public void setNume(String nume) {
	this.nume = nume;
}
public int getVarsta() {
	return varsta;
}
public void setVarsta(int varsta) {
	this.varsta = varsta;
}
public student(String nume, int varsta){
	this.nume = nume;
	this.varsta = varsta;
}
public String manumesc() {
	return "Ma numesc " + nume + "si am " + varsta + "ani";
}
}
