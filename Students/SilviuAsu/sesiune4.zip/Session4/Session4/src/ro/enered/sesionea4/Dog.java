package ro.enered.sesionea4;

public class Dog {
	String name, color;
	int age;
	public Dog(String name,String color,int age){
		this.name = name;
		this.color = color;
		this.age = age;
		
	}
	public Dog(){
		
	}
	public void talk(){
		System.out.println("Bark");
	}
	public void walk(int km){
		System.out.println("Pisica a mers " + km + " km");
	}
}
