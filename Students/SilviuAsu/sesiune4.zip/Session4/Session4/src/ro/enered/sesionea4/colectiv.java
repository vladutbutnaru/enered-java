package ro.enered.sesionea4;

public class colectiv {
student studen1;
student studen2;
public student getStuden1() {
	return studen1;
}
public void setStuden1(student studen1) {
	this.studen1 = studen1;
}
public student getStuden2() {
	return studen2;
}
public void setStuden2(student studen2) {
	this.studen2 = studen2;
}
public void rcolectiv(){
	System.out.println(studen1.manumesc());
	System.out.println(studen2.manumesc());
}
}
