package ro.enered.Sesiune4;

public class Main {
	public static void main(String[] args) {
		//instantiere
Cat pisica = new Cat("Tom", "alba" ,4);//folosuim parametrii dati
Qwner gigel = new Qwner();// pentru astea nu am parametrii 
Dog dog= new Dog();
int km=7;
Controller c= new Controller();


//apelare de functii se fac pe instantele date obiectelor.functia ..apelez pisica cu functia talk
gigel.setCat(pisica);
gigel.setDog(dog);

pisica.talk();
pisica.walk( km );
pisica.setName("Tom");
c.callMethod();
gigel.walkAnimals(6);


//afisare
System.out.println(pisica.suffix("ului"));


	

	
}
}


