package ro.enered.Sesiune4;

public class Controller {
public void callMethod(){
	// vreau sa apelez metoda walkAnimals din owner cu paramentrul 7

	Qwner o= new Qwner();
	o.setDog(new Dog());
	o.setCat(new Cat("Tom2","Rosie",4));
	o.walkAnimals(8);
}
	
}
