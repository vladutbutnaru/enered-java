package ro.enered.Sesiune4;

public class Qwner {
String name;
Dog dog;
Cat cat;
public String getName() {
	return name;
}
public void setName(String name) {
	this.name = name;
}
public Dog getDog() {
	return dog;
}
public void setDog(Dog dog) {
	this.dog = dog;
}
public Cat getCat() {
	return cat;
}
public void setCat(Cat cat) {
	this.cat = cat;
}
public void walkAnimals(int km){
	dog.walk(km);//varb albastre sunt instante
	cat.walk(km);
}
}
