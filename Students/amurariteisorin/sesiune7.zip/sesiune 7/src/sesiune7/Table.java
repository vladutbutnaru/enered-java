package sesiune7;

import java.util.ArrayList;

public class Table {
private boolean available;
private int nrMasa;
ArrayList<User>users;
//Constructor START
public Table(int index){
	setIndex(index); //this.index=index;
	users = new ArrayList<User>(); //instantiem
	setAvailable (true); //la inceput sunt available
	
}
//Constructor END
//setter&Getter START
public boolean isAvailable() {
	return available;
}
public void setAvailable(boolean available) {
	this.available = available;
}
public int getnrMasa() {
	return nrMasa;
}
public void setIndex(int index) {
	this.nrMasa = index;
}
public ArrayList<User> getUsers() {
	return users;
}
public void setUsers(ArrayList<User> users) {
	this.users = users;
}
//Setter&Getter END
public void reserve(User u){
	if (isAvailable()){
		users.add(u);
	setAvailable(false);
	System.out.println("THe table was reserved successfully");
	}else{
		System.out.println("The table is already reserved");
	}
}
public void leaveTable(){
	setAvailable(true);
	
}
public void showHistory(){
	System.out.println("The table with number: "+ getnrMasa()+ " had the following customers: ");
	for (int i = 0; i<users.size();i++){
		System.out.println(users.get(i).getName());
	}
	System.out.println();
}
	
}
