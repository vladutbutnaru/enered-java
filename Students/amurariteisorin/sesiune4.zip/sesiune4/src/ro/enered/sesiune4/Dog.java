package ro.enered.sesiune4;

public class Dog {
	String nume,culoare,dimensiune;
	public String getNume() {
		return nume;
	}
	public void setNume(String nume) {
		this.nume = nume;
	}
	public String getCuloare() {
		return culoare;
	}
	public void setCuloare(String culoare) {
		this.culoare = culoare;
	}
	public String getDimensiune() {
		return dimensiune;
	}
	public void setDimensiune(String dimensiune) {
		this.dimensiune = dimensiune;
	}
	public int getVarsata() {
		return varsata;
	}
	public void setVarsata(int varsata) {
		this.varsata = varsata;
	}
	int varsata;
	public String talk(){
		return "Hamulica";
	}
	public void walk(int km){
		System.out.println("The dog walked " + km + " km");
	}
}
