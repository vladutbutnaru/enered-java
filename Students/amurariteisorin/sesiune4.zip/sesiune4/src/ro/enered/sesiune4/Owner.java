package ro.enered.sesiune4;

public class Owner {
	// nume caine pisica
String nume;
Cat cat;
Dog dog;	


public String getNume() {
	return nume;
}
public void setNume(String nume) {
	this.nume = nume;
}
public Dog getDog() {
	return dog;
}
public void setDog(Dog dog) {
	this.dog = dog;
}
public Cat getCat() {
	return cat;
}
public void setCat(Cat cat) {
	this.cat = cat;
}
public void walkAnimals(int km){
	dog.walk(km);
	cat.walk(km);

}
}