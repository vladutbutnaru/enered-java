package ro.enered.sesiune4;

public class Main {
	public static void main(String[] args) {
		Student Andrei = new Student("Andrei", 22);
		Student Cristi = new Student ();
		Cristi.setNume("Cristi");
		Cristi.setVarsta(23);
		System.out.println(Andrei.returneaza());
		System.out.println(Cristi.returneaza());
		Colectiv c1 = new Colectiv();
		c1.setStudent1(Andrei);
		c1.setStudent2(Cristi);
		c1.rcolectiv();
	}
	
}
