package ro.enered.sesiune4;

public class Controller {
public void callMethod() {
	Owner o = new Owner ();
	o.setDog(new Dog());
	o.setCat(new Cat("Garfield", "neagra", 4));
	o.walkAnimals(8);
}
}
