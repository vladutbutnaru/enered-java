package sesiune5;

public class Main {
	
		public static void main(String[] args){
//creare harta
		char[][] map = new char [15][15];
		
		for (int i = 0; i<map.length; i++){
			for (int j = 0; j<map.length;j++){
				map[i][j] = 'o';
				
				if (i==7 && j ==12)
					map [i][j] = 'm'; //soarece
				
				if (i==2 && j ==3)
					map [i][j] = 'c'; //cascaval
				
				if (i==10&& j ==10)
					map [i][j] = 'x'; //obstacol	
			   
				}
			}
			Map harta1 = new Map();
			Mouse soarece = new Mouse();
			Cheese cascaval = new Cheese();
			
			harta1.setMap(map);
			harta1.display();
			
			soarece.find(harta1);
			cascaval.find(harta1);
			
			while (!cascaval.isFound(harta1)){  //! true  = false;
				if (cascaval.getX() > soarece.getX())
					soarece.moveDown(harta1);  // cascavalul este deasupra
				if (cascaval.getX() < soarece.getX())
					soarece.moveUp(harta1); //cascavalul este dedesubt
				if (cascaval.getX() == soarece.getX()) { //am gasit linia
					if (cascaval.getY() > soarece.getY())
						soarece.moveRight(harta1); // cascavalul este in dreapta
					if (cascaval.getY()< soarece.getY())
						soarece.moveLeft (harta1); // cascavalul este la stanga
				}
			}
			System.out.println();
			harta1.display();
		}
	}
			