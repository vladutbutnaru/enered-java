package sesiune8;

import ro.enered.masininherit.Asigurare;
import ro.enered.masininherit.Asigurator;
import ro.interfaces.Airplane;
import ro.interfaces.ProdusAlimentar;
import ro.interfaces.ProdusNealimentar;

public class Main {

	public static void main(String[] args) {
		Cat garfield=new Cat();
		  garfield.setColor("orange");
		  garfield.miauna();
		  garfield.miauna(6);
		  //interfaces
		  Airplane boeing = new Airplane();
		  boeing.setNumOfAirplanes(10);
		  System.out.println(boeing.count());
		  ProdusAlimentar bere = new ProdusAlimentar();
		  ProdusNealimentar clor = new ProdusNealimentar();
		  bere.setPrice(3.5);
		  clor.setPrice(2.1);
		  System.out.println("the price of beer "+bere.calculatePrice()+" Ron");
		  System.out.println("the price of clorum " + clor.calculatePrice()+ " Ron");
		  
		  Asigurare asigurare = new Asigurare ();
		  Asigurator omniasig = new Asigurator();
		  asigurare.setColor("green");
		  asigurare.setExpiry("12/12/2012");
		  asigurare.setNrAuto("IS 03 ASA");
		  omniasig.setColor("blue");
		  System.out.println(asigurare.getExpiry());
		  
	}

}
