package sesiune8;

public class Bicycle extends Vehicle{
private boolean hasBell;

public boolean isHasBell() {
	return hasBell;
}

public void setHasBell(boolean hasBell) {
	this.hasBell = hasBell;
	} 
}
