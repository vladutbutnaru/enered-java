package sesiune8;
public class Cat extends Animal {
	 public void miauna(){
	  if(super.isMamnifer())
	   System.out.println("The Mammal with color "+super.getColor()+" says Miau !");
	  else
	   System.out.println("The cat with color "+super.getColor()+" says Miau !");
	 }
public void miauna (int numOfTimes){
	for (int i=0; i<numOfTimes;i++){
		System.out.println("The cat with color"+ super.getColor()+" says meow");
	}
}
	}