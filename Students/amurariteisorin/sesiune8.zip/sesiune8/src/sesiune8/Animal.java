package sesiune8;

public class Animal {
	 private String color;
	 private boolean mamnifer;
	 
	 public String getColor() {
	  return color;
	 }
	 public void setColor(String color) {
	  this.color = color;
	 }
	 public boolean isMamnifer() {
	  return mamnifer;
	 }
	 public void setMamnifer(boolean mamnifer) {
	  this.mamnifer = mamnifer;
	 }
	 

	}