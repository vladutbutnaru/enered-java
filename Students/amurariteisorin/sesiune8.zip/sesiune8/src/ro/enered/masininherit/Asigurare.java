package ro.enered.masininherit;

public class Asigurare extends Masina {
private String expiry;

public String getExpiry() {
	return expiry;
}

public void setExpiry(String expiry) {
	this.expiry = expiry;	
}
public void pay(){
	System.out.println("RCA costa stantard 300 lei");
}

}
