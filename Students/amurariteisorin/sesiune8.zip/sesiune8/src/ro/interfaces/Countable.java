package ro.interfaces;

public interface Countable {
public int count();
}
