package ro.interfaces;

public interface Tva {
public double calculatePrice();

}
