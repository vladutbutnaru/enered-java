package sesiune5;

public class Main {
	
		public static void main(String[] args){
//creare harta
	
			
			Mouse soarece = new Mouse();
			Cheese cascaval = new Cheese();
			Map harta1 = new Map();
		
			
			Engine controller = new Engine();
			harta1 = controller.generateRandomMap();
			
			
			soarece.find(harta1);
			cascaval.find(harta1);
			harta1.display();
			//controller.play(cascaval, harta1, soarece);
			controller.playAvoidingObstacles(cascaval, harta1, soarece);
			System.out.println();
			harta1.display();
		}
	}
			