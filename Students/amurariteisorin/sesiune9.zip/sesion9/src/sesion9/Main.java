package sesion9;

public class Main {

	public static void main(String[] args) {
	Test t1 = new Test();
	Test t2 = new Test();
	Test t3 = new Test();
	
	System.out.println(t3.numberOfInstances);
	t1.run();
	}
}

/*1. Inheritance
 * a. create SuperClass;
 * b. create 2nd class and use class2 extends SuperClass
 * cum ajungi la met din superclasa : super.(method)
 * super (...)  asa se apeleaza constructoru; 
 * 
 * 2. Interface

 * Diferenta intre interfata si inheritance:
 * 
 * a. create interface;
 * 	public interface Countable {
 *  public void count();
 *  }
 *  b. Use it:
 *  public class Apple implements Countable{}
 *  c. OVERRIDING and OVERLOADING
 *  	public String display(){
 *  	
 *  }
 *
 * 
 * 
*/
