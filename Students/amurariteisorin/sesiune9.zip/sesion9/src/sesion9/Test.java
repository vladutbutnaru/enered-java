package sesion9;

public class Test extends AbstractTest {
	private final int pi = (int)3.14;
	static int numberOfInstances = 0;
		
	public int getpi() {
		return pi;
	}
	public Test() {
		numberOfInstances++;
	}
}
