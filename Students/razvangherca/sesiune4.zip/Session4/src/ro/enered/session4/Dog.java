package ro.enered.session4;

public class Dog {
	String name,color;
	int age;
	
	
	public String getColor() {
		return color;
	}

	public void setColor(String color) {
		this.color = color;
	}

	public int getAge() {
		return age;
	}

	public void setAge(int age) {
		this.age = age;
	}

	public String getName() {
		return name;
	}

	public Dog(String name,String color,int age){
		setName(name);
		this.color=color;
		this.age=age;
	}
	
	public void talk(){
		System.out.println("Wof!");
	}
	
	public void walk(int Km){
		System.out.println("Cainele a mers "+Km+" km.");
	}
	public String suffix(String sufix){
		return name+sufix;
	}
	
	public void setName(String name){
		this.name=name;
	}

}
