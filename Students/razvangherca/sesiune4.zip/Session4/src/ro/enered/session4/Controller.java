package ro.enered.session4;

public class Controller {
	public void callMethod(){
		//vreau sa apelez metoda walkAnimals din Owner cu parametrul 7;
		Owner o=new Owner();
		o.setDog(new Dog("Mimi","black",2));
		o.setCat(new Cat("Miri","creme",3));
		o.walkAnimals(7);
	}

}
