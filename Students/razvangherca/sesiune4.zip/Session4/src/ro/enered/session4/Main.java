package ro.enered.session4;

public class Main {
	public static void main(String[] args){
		//instantiere
		Cat pisica=new Cat("Garfield","orange",4);
        Owner gigel=new Owner();
		Dog d=new Dog("Winnie","white",4);
		Controller c=new Controller();
		int kilometers=7;
		//setteri;
		gigel.setCat(pisica);
		gigel.setDog(d);
		//apeluri de functii
		pisica.talk();
		pisica.walk(kilometers);
		gigel.walkAnimals(6);
	    c.callMethod();
		//afisari
		System.out.println(pisica.suffix("ului"));
		System.out.println();
		
		
		
	
	}

}
