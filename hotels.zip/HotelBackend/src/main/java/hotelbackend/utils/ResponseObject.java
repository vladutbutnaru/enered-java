package hotelbackend.utils;

public class ResponseObject {
	private String message;
	
	//getters and setters

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}
	
	
}
