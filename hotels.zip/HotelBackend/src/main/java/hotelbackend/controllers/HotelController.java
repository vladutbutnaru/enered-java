package hotelbackend.controllers;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Timestamp;
import java.util.ArrayList;

import hotelbackend.beans.Hotel;
import hotelbackend.beans.Room;
import hotelbackend.utils.DBConnection;

public class HotelController {
	static Connection con = DBConnection.getConnection();
	
	public static ArrayList<Hotel> searchHotels(String destination, Timestamp checkIn, Timestamp checkOut, int nrRooms, int currency){
		ArrayList<Hotel> hotels =new ArrayList<Hotel>();
		try{
			
			//get all hotels in the destination
			PreparedStatement ps = con.prepareStatement("SELECT * FROM Hotels WHERE city = ?");
			ps.setString(1, destination);
			ResultSet rs = ps.executeQuery();
			while(rs.next()){
				//for each hotel, get all the rooms
				ArrayList<Room> rooms = RoomController.getRoomsForHotel(rs.getInt(1));
				int roomsFound = 0;
				//for each room, count the rooms that are available
				for(Room r : rooms){
					if(RoomController.getLastCheckoutForRoom(r.getId()).before(checkIn)){
						//for each available room, increment roomsFound
						roomsFound++;
						
						
					}
					
				}
				//if the number of available rooms is equal to the number of searched rooms, add hotel to list
				if(roomsFound >= nrRooms){
					Hotel h = new Hotel();
					h.setId(rs.getInt(1));
					h.setImage(rs.getString(2));
					h.setHotelName(rs.getString(3));
					h.setStars(rs.getInt(4));
					h.setRating(rs.getDouble(5));
					h.setCity(rs.getString(6));
					h.setDescription(rs.getString(7));
					h.setImages(rs.getString(8));
					
					hotels.add(h);
				}
				
				
			}
			
		}
		catch(Exception e){
			e.printStackTrace();
			System.out.println(e.getStackTrace() + " " + e.getMessage());	
		}
		
		
		return hotels;
		
	}
}
