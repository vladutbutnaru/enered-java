package hotelbackend.controllers;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Timestamp;
import java.util.ArrayList;

import hotelbackend.beans.Room;
import hotelbackend.utils.DBConnection;

public class RoomController {
	static Connection con = DBConnection.getConnection();
	
	public static ArrayList<Room> getRoomsForHotel(int idHotel){
		
		ArrayList<Room> rooms = new ArrayList<Room>();
			try{
			
			//get all rooms for hotel
			PreparedStatement ps = con.prepareStatement("SELECT * FROM Rooms WHERE id_hotel = ?");
			ps.setInt(1, idHotel);
			ResultSet rs = ps.executeQuery();
			while(rs.next()){
				Room r = new Room();
				r.setId(rs.getInt(1));
				r.setImage(rs.getString(2));
				r.setTitle(rs.getString(3));
				rooms.add(r);
				
			}
			
		}
		catch(Exception e){
			e.printStackTrace();
			System.out.println(e.getStackTrace() + " " + e.getMessage());	
			
		}
		
		return rooms;

	}
		
	public static Timestamp getLastCheckoutForRoom(int roomID){
		try{
			PreparedStatement ps = con.prepareStatement("SELECT checkout FROM Reservations WHERE room_id = ? ORDER BY checkout DESC LIMIT 1");
			ps.setInt(1, roomID);
			ResultSet rs = ps.executeQuery();
			if(rs.next()){
				return rs.getTimestamp(1);
				
			}
		}
		catch(Exception e){
			e.printStackTrace();
			System.out.println(e.getStackTrace() + " " + e.getMessage());	
			
		}
		return null;
	}
}
