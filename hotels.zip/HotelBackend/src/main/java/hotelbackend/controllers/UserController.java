package hotelbackend.controllers;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import hotelbackend.beans.User;
import hotelbackend.utils.DBConnection;

public class UserController {

	Connection con = DBConnection.getConnection();

	// method for registration of a new user
	public boolean register(User u) {
		if (!checkUserDuplicate(u)) {
			try {
				PreparedStatement ps = con.prepareStatement(
						"INSERT INTO Users(first_name, email, password, last_name)" + " VALUES (?,?,?,?)");
				ps.setString(1, u.getFirstName());
				ps.setString(2, u.getEmail());
				ps.setString(3, u.getPassword());
				ps.setString(4, u.getLastName());
				ps.executeUpdate();

			} catch (Exception e) {
				System.out.println(e.getMessage() + " " + e.getStackTrace());
			}
			return true;
		}

		return false;

	}

	// method that verifies if an user with the same email address exists
	public boolean checkUserDuplicate(User u) {
		boolean exists = false;
		try {
			PreparedStatement ps = con.prepareStatement("SELECT email FROM Users WHERE email = ?");
			ps.setString(1, u.getEmail());
			ResultSet rs = ps.executeQuery();
			if (rs.next()) {
				exists = true;

			}

		} catch (Exception e) {
			System.out.println(e.getMessage() + " " + e.getStackTrace());
		}

		return exists;
	}

	// method that verifies login data
	public boolean login(User u){
		boolean exists = false;
		try {
			PreparedStatement ps = con.prepareStatement("SELECT email FROM Users WHERE email = ? AND password = ?");
			ps.setString(1, u.getEmail());
			ps.setString(2, u.getPassword());
			ResultSet rs = ps.executeQuery();
			if (rs.next()) {
				exists = true;

			}

		} catch (Exception e) {
			System.out.println(e.getMessage() + " " + e.getStackTrace());
		}

		return exists;
		
		
		
	}

}
