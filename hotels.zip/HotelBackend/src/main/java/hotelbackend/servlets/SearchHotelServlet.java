package hotelbackend.servlets;

import java.io.IOException;
import java.sql.Timestamp;
import java.util.ArrayList;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.google.gson.Gson;

import hotelbackend.beans.Hotel;
import hotelbackend.controllers.HotelController;

/**
 * Servlet implementation class SearchHotelServlet
 */
public class SearchHotelServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public SearchHotelServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String destination = request.getParameter("destination");
		// LL/ZZ/AAAA
		String checkin = request.getParameter("checkin");
		String checkout = request.getParameter("checkout");
		
		int nrRooms = Integer.parseInt(request.getParameter("nrRooms"));
		
		
		int year = Integer.parseInt(checkin.split("/")[2]) - 1900;
		int month = Integer.parseInt(checkin.split("/")[0]) - 1;
		int day = Integer.parseInt(checkin.split("/")[1]);
		
		Timestamp checkIn = new Timestamp(year, month, day,0,0,0,0);
		
		year  = Integer.parseInt(checkout.split("/")[2]) - 1900;
		month =  Integer.parseInt(checkout.split("/")[0]) - 1;
		day = Integer.parseInt(checkout.split("/")[1]);
		
		Timestamp checkOut = new Timestamp(year, month, day,0,0,0,0);
	
		ArrayList<Hotel> hotels = HotelController.searchHotels(destination, checkIn, checkOut, nrRooms, 1);
		response.setContentType("application/json");
		response.getWriter().write(new Gson().toJson(hotels));
		
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
