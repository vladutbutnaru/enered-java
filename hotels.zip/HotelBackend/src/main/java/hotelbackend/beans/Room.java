package hotelbackend.beans;

public class Room {
	private int id;
	private String image;
	private String title;
	private String breakfastTitle;
	private double breakfastPrice;
	private int capacity;
	private double price;
	private String description;
	private String facilities;
	private String bedType;
	private String roomSize;
	private String pets;
	private String acceptedCreditCards;
	private String coordinates;
	private double score;
	private int numberOfReviews;
	private Hotel hotel;
	
	
	//getters and setters
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getImage() {
		return image;
	}
	public void setImage(String image) {
		this.image = image;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public String getBreakfastTitle() {
		return breakfastTitle;
	}
	public void setBreakfastTitle(String breakfastTitle) {
		this.breakfastTitle = breakfastTitle;
	}
	public double getBreakfastPrice() {
		return breakfastPrice;
	}
	public void setBreakfastPrice(double breakfastPrice) {
		this.breakfastPrice = breakfastPrice;
	}
	public int getCapacity() {
		return capacity;
	}
	public void setCapacity(int capacity) {
		this.capacity = capacity;
	}
	public double getPrice() {
		return price;
	}
	public void setPrice(double price) {
		this.price = price;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public String getFacilities() {
		return facilities;
	}
	public void setFacilities(String facilities) {
		this.facilities = facilities;
	}
	public String getBedType() {
		return bedType;
	}
	public void setBedType(String bedType) {
		this.bedType = bedType;
	}
	public String getRoomSize() {
		return roomSize;
	}
	public void setRoomSize(String roomSize) {
		this.roomSize = roomSize;
	}
	public String getPets() {
		return pets;
	}
	public void setPets(String pets) {
		this.pets = pets;
	}
	public String getAcceptedCreditCards() {
		return acceptedCreditCards;
	}
	public void setAcceptedCreditCards(String acceptedCreditCards) {
		this.acceptedCreditCards = acceptedCreditCards;
	}
	public String getCoordinates() {
		return coordinates;
	}
	public void setCoordinates(String coordinates) {
		this.coordinates = coordinates;
	}
	public double getScore() {
		return score;
	}
	public void setScore(double score) {
		this.score = score;
	}
	public int getNumberOfReviews() {
		return numberOfReviews;
	}
	public void setNumberOfReviews(int numberOfReviews) {
		this.numberOfReviews = numberOfReviews;
	}
	public Hotel getHotel() {
		return hotel;
	}
	public void setHotel(Hotel hotel) {
		this.hotel = hotel;
	}
	
	
	
	
	
	
}
