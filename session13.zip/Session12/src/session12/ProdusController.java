/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package session12;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Date;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author Vlad Butnaru
 */
public class ProdusController implements CRUDable {
    DBConnection con = new DBConnection();
    PreparedStatement ps;
    @Override
    public void create(Object a) {
       Produs p = (Produs) a;
       Connection c = con.getConnection();
        try {
            ps = c.prepareStatement("INSERT INTO Produse(Nume,UM,Cantitate,Categorie,Creator) VALUES(?,?,?,?,?)");
            ps.setString(1, p.getNume());
            ps.setString(2, p.getUm());
            ps.setInt(3, p.getCantitate());
            ps.setInt(4, p.getC().getId());
           // ps.setDate(5, (java.sql.Date) new Date());
            ps.setInt(5, p.getCreator());
            ps.execute();
        } catch (SQLException ex) {
            Logger.getLogger(ProdusController.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    @Override
    public void update(Object a) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public void delete(Object a) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public ArrayList<String> read() {
        ArrayList<String> produse = new ArrayList<String>();
        String query = "SELECT * FROM Produse";
        Connection c = con.getConnection();
        try {
            Statement s = c.createStatement();
            ResultSet rs = s.executeQuery(query);
            while(rs.next()){
            produse.add(rs.getString("Nume"));
            
            }
        } catch (SQLException ex) {
            Logger.getLogger(ProdusController.class.getName()).log(Level.SEVERE, null, ex);
        }
        return produse;
        
    }
    
}
