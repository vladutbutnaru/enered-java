package ro.enered.bank.controllers;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import ro.enered.bank.utils.DBConnection;

public class ATMUserController {
	DBConnection con = new DBConnection();

	
	
	public boolean checkCredentials(String cardNumber, String PIN){
		Connection conn =  con.getConnection();
		Statement stmt = null;
		ResultSet rs = null;
		
		 
		try {
		    stmt = conn.createStatement();
		    rs = stmt.executeQuery("SELECT * FROM Accounts WHERE CardNumber = '" + cardNumber + "' AND PIN = '"+PIN+"';");
		    if(rs.first()){
		    	return true;	 
		    
		    }

		  
		}
		catch (SQLException ex){
		    // handle any errors
		    System.out.println("SQLException: " + ex.getMessage());
		    System.out.println("SQLState: " + ex.getSQLState());
		    System.out.println("VendorError: " + ex.getErrorCode());
		   
		}
		return false;
		
		
		
	}
}
