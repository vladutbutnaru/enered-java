package ro.enered.bank.controllers;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import ro.enered.bank.entities.Account;
import ro.enered.bank.utils.DBConnection;

public class ATMBalantaController {
	
	public static Account getBalanta(String cardNumber ){
		DBConnection con=new DBConnection();
		Connection conn =  con.getConnection();
		Statement stmt = null;
		ResultSet rs = null;
		Account cont=new Account();
		 
		try {
		    stmt = conn.createStatement();
		    rs = stmt.executeQuery("SELECT NumarCont,Balanta FROM Accounts WHERE CardNumber = '" + cardNumber + "';");
		    if(rs.first()){
		    
		    cont.setBalanta(Double.parseDouble(rs.getString("Balanta")));
		    cont.setNumarCont(rs.getString("NumarCont"));
		    
		    
		    }

		 
		}
		catch (SQLException ex){
		    // handle any errors
		    System.out.println("SQLException: " + ex.getMessage());
		    System.out.println("SQLState: " + ex.getSQLState());
		    System.out.println("VendorError: " + ex.getErrorCode());
		   
		}
		 return cont;
	}

}
