package ro.enered.bank.entities;

import ro.enered.bank.utils.Contants;

public class Account {
	private int ID;
	private int IdUser;
	private String valuta;
	private String numarCont;
	private int tip;
	private double balanta;
	private int status;
	public int getID() {
		return ID;
	}
	public void setID(int iD) {
		ID = iD;
	}
	public int getIdUser() {
		return IdUser;
	}
	public void setIdUser(int idUser) {
		IdUser = idUser;
	}
	public String getValuta() {
		return valuta;
	}
	public void setValuta(String valuta) {
		this.valuta = valuta;
	}
	public String getNumarCont() {
		return numarCont;
	}
	public void setNumarCont(String numarCont) {
		this.numarCont = numarCont;
	}
	public int getTip() {
		return tip;
	}
	public void setTip(int tip) {
		this.tip = tip;
	}
	public double getBalanta() {
		return balanta;
	}
	public void setBalanta(double balanta) {
		this.balanta = balanta;
	}
	public int getStatus() {
		if(status == Contants.CLOSED){
			return Contants.CLOSED;
		}
		return Contants.ACTIVE;
	}
	public void setStatus(int status) {
		this.status = status;
	}
}
