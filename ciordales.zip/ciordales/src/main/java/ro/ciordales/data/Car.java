package ro.ciordales.data;

public class Car {
	   public String name;
	    public String link;
	    public String price;
	    public String location;
	    public String image;
}
