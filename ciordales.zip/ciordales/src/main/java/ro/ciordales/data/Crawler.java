package ro.ciordales.data;
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;
import org.jsoup.Jsoup;

import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;
public class Crawler {
	private static ArrayList<Car> totalCars = new ArrayList<Car>();
	 public static void crawl(String url, int page){
         ArrayList<Car> crawledCars = new ArrayList<Car>();
   try {
           
           Document doc = Jsoup.connect(url).get();
           Elements promotedCars = doc.select("a.detailsLink");
           Elements carPrices = doc.select("p.price");
           Elements carLocations = doc.select("small.breadcrumb");
           Elements carImages = doc.select("img.fleft");
           Elements carLinks = doc.select("a.detailsLink");
//get names
           for(Element e : promotedCars){
           Car c = new Car();
           c.name = e.text();
           crawledCars.add(c);
           }
           
           //get prices
          int i = 0;
           for(Car c : crawledCars){
               try{
                   System.out.println(carPrices.get(i).text());
          c.price = carPrices.get(i).text();
          
               }
               catch(Exception e){}
          
          i++;
          }
           
           //get location
        i = 1;
           for(Car c : crawledCars){
               try{
          c.location = carLocations.get(i).text();
          System.out.println(c.toString());
          
               }
               catch(Exception e){}
          
          i=i+2;
          }
           
          //get images
          i = 0;
           for(Car c : crawledCars){
               try{
                  
          c.image = carImages.get(i).attr("src");
          
               }
               catch(Exception e){}
          
          i++;
          }
           
           //get links
          i = 0;
           for(Car c : crawledCars){
               try{
                  
          c.link = carLinks.get(i).attr("href");
          System.out.println(c.toString());
               }
               catch(Exception e){}
          
          i++;
          }
       
       
       
       } catch (IOException ex) {
              }
   totalCars.addAll(crawledCars);
   }
	 public static void insertCars(){
		   Connection c = DBConnection.getConnection();
	        for(Car car : totalCars)
	            if(car.name!=null && !car.name.equals("") && car.price!=null && !car.price.equals(""))
	        try {
	            PreparedStatement ps = c.prepareStatement(""
	                    + "INSERT INTO CarsEnered(title,link,price,location) "
	                    + "VALUES(?,?,?,?)"
	                    + "");
	            
	            ps.setString(1, car.name);
	            ps.setString(2, car.link);
	            ps.setString(3, car.price);
	            ps.setString(4,car.location);
	            ps.executeUpdate();
	        } catch (SQLException ex) {
	                }
		 
		 
	 }
}
