package ro.ciordales.data;

public class Configuration {
    public static final String DATABASE_URL = "invata-acum.club";
    public static final int DATABASE_PORT = 3306;
    public static final String DATABASE_NAME = "Scrapers";
    public static final String DATABASE_USER = "root";
    public static final String DATABASE_PASSWORD = "BaniiMeiDev1!";
}
