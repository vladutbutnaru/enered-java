$(window).on("load", function () {
  $(".loader").hide();
   $("#crawl").click(function(){
       crawl();
       $(".loader").show();
       
   });
    
});
function crawl(){
    $.get("http://localhost:8080/ciordales/StartCrawlingServlet",{},function(data){
        
        getCars();
        $(".loader").hide();
        
    });
    
    
}
function getCars(){
    $.get("http://localhost:8080/ciordales/GetCarsServlet",{},function(data){
     var x = "<tr><td>Nume</td><td>Link</td><td>Pret</td><td>Locatie</td></tr>";
        data = JSON.parse(data);
        for(var i = 0; i<data.length; i++)
        x+="<tr><td>"+data[i].name.replace("�","tz")+"</td><td><a href='"+data[i].link+"'>Link</a></td><td>"+data[i].price.replace("?","")+"</td><td>"+data[i].location+"</td></tr>";
        
        $("#cars").html(x);
    });
    
    
    
}