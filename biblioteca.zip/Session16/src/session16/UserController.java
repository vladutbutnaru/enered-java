/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package session16;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author Vlad Butnaru
 */
public class UserController {
    
    DBConnection con = new DBConnection();
    Connection conn = con.getConnection();
    
    public ArrayList<User> getAll() {
        
        ArrayList<User> uList = new ArrayList<User>();
        String query = "select * from User";
        try {
            Statement s = conn.createStatement();
            ResultSet rs = s.executeQuery(query);
            
            while(rs.next()) {
                User u = new User();
                u.setId(rs.getInt(0));
                u.setNume(rs.getString(1));
                u.setParola(rs.getString(2));
                if (rs.getInt(3) == 1){
                    u.setAdmin(true);
                }else {
                    u.setAdmin(false);
                }
                u.setCnp(rs.getInt(4));
                uList.add(u);
            }
            
        } catch (SQLException ex) {
            Logger.getLogger(UserController.class.getName()).log(Level.SEVERE, null, ex);
        }
        return uList;
    }
    
}
