/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package session12;

/**
 *
 * @author Vlad Butnaru
 */
public class Session12 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        StressThread st = new StressThread();
        StressThread st2 = new StressThread();
        st.numeThread = "Fir 1";
        st2.numeThread = "Fir 2";
        st.run();
        st2.run();
    }
    
}
