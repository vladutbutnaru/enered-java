/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package session12;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author Vlad Butnaru
 */
public class CategorieController implements CRUDable {
  DBConnection con = new DBConnection();
    @Override
    public void create(Object a) {
        //create a db conn
      
        //insert data in c
        Connection c = con.getConnection();
        //cast object a
        Categorie cat = (Categorie) a;
        try {
            PreparedStatement p = c.prepareStatement("INSERT INTO Categorii (Nume) "
                    + "VALUES (?)");
            p.setString(1,cat.getNumeCategorie());
            p.execute();
        } catch (SQLException ex) {
            Logger.getLogger(CategorieController.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        
        
    }

    @Override
    public void update(Object a,String oldName) {
        
    
        //insert data in c
        Connection c = con.getConnection();
        //cast object a
        Categorie cat = (Categorie) a;
        try {
            PreparedStatement p = c.prepareStatement("UPDATE Categorii SET Nume = ? WHERE Nume = ?");
            p.setString(1,cat.getNumeCategorie());
            p.setString(2,oldName);
            p.execute();
        } catch (SQLException ex) {
            Logger.getLogger(CategorieController.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        
    }

    @Override
    public void delete(Object a) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public ArrayList<String> read() {
      ArrayList<String> categorii = new ArrayList<String>();
        String query = "SELECT * FROM Categorii";
        Connection c = con.getConnection();
        try {
            Statement s = c.createStatement();
            ResultSet rs = s.executeQuery(query);
            while(rs.next()){
            categorii.add(rs.getString("Nume"));
            
            }
        } catch (SQLException ex) {
            Logger.getLogger(ProdusController.class.getName()).log(Level.SEVERE, null, ex);
        }
        return categorii;
    }
    
    
    
    
}
