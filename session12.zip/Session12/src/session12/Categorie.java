/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package session12;

/**
 *
 * @author Vlad Butnaru
 */
public class Categorie {
    private int id;
    private String numeCategorie;
    public String stare;
    public static int nrOfInstances =0;
    CategoryFilter filter = new CategoryFilter();
public Categorie(){
nrOfInstances++;
}
    public int getId() {
        return id;
    }

    public void setId(int id) {
        if(filter.checkID(id))
        this.id = id;
        else
            System.out.println("ID trebuie sa fie mai mare ca 3");
    }

    public String getNumeCategorie() {
        return numeCategorie;
    }

    public void setNumeCategorie(String numeCategorie) {
        this.numeCategorie = numeCategorie;
    }
}
