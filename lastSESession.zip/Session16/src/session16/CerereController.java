package session16;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;

public class CerereController {

    DBConnection con = new DBConnection();
    Connection conn = con.getConnection();

    public ArrayList<Cerere> getAll() {

        ArrayList<Cerere> cereriList = new ArrayList<Cerere>();
        String query = "select * from Cereri WHERE Status='Pending'";
        try {
            Statement s = conn.createStatement();
            ResultSet rs = s.executeQuery(query);

            while (rs.next()) {
                Cerere ce = new Cerere();
                ce.setId(rs.getInt(1));
                ce.setIdCarte(rs.getInt(2));
                ce.setIdUser(rs.getInt(3));

           
                ce.setNrZile(rs.getInt(4));
                ce.setStatus(rs.getString(5));
                cereriList.add(ce);
            }

        } catch (SQLException ex) {
            Logger.getLogger(UserController.class.getName()).log(Level.SEVERE, null, ex);
        }
        return cereriList;
    }

    public Cerere getById(int id) {
        String query = "Select * from Cereri where ID=" + id;
        Cerere cer = new Cerere();
        try {
            Statement st = conn.createStatement();

            ResultSet rs = st.executeQuery(query);
            while (rs.next()) {
                cer.setId(rs.getInt(1));
                cer.setIdCarte(rs.getInt(2));
                cer.setIdUser(rs.getInt(3));
                cer.setNrZile(rs.getInt(4));
                cer.setStatus(rs.getString(5));
              

            }
        } catch (SQLException ex) {
            Logger.getLogger(CarteController.class.getName()).log(Level.SEVERE, null, ex);
        }
        return cer;
    }
    public void add(Cerere cr) {
        try {
            String query = "INSERT INTO Cereri "
                    + "(idCarte,idUser ,"
                    + " nrZile, Status )"
                    + "Values("+ cr.getIdCarte()+","
                    + cr.getIdUser()+","                   
                    + cr.getNrZile()+",'"
                    + cr.getStatus()+"')";
            Statement s = conn.createStatement();
            s.executeUpdate(query);
        } catch (SQLException ex) {
            Logger.getLogger(CerereController.class.getName()).log(Level.SEVERE, null, ex);
        }
        
    }
    public void aprobareCerere(Cerere c){
        try {
            PreparedStatement pst;
            pst=conn.prepareStatement("update Cereri set Status='Approved' where ID=?");
            pst.setInt(1, c.getId());
            pst.executeUpdate();
            
        } catch (SQLException ex) {
            Logger.getLogger(CerereController.class.getName()).log(Level.SEVERE, null, ex);
        }
        
    }
    public void respingeCerere (Cerere c){
    String query = "update Cereri set Status = 'Rejected' where Id = " + c.getId();
        try {
            Statement s = conn.createStatement();
            s.executeUpdate(query);
        } catch (SQLException ex) {
            Logger.getLogger(CerereController.class.getName()).log(Level.SEVERE, null, ex);
        }
    
    
    }
}
