package ro.enered.DAO;

import java.util.List;

import ro.enered.beans.User;

public interface UserDAO {
	
	public void addUser(User u);

	public void updateUser(User u);

	public List<User> listUsers();

	public User getUserById(int id);

	public void removeUser(int id);
}
